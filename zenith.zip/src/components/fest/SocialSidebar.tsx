import { Instagram, Youtube, Facebook } from "lucide-react";

const LINKS = [
  {
    label: "WhatsApp",
    href: "https://wa.me/9411400557",
    color: "from-emerald-400 to-emerald-600",
    icon: (
      <svg
        viewBox="0 0 24 24"
        className="size-5 sm:size-6 text-white"
        fill="currentColor"
      >
        <path d="M20.52 3.48A11.79 11.79 0 0 0 12.05 0C5.52 0 .2 5.31.2 11.84c0 2.09.55 4.13 1.59 5.93L.1 24l6.37-1.67a11.84 11.84 0 0 0 5.57 1.42h.01c6.53 0 11.84-5.31 11.84-11.84 0-3.16-1.23-6.13-3.37-8.43ZM12.05 21.8h-.01a9.86 9.86 0 0 1-5.03-1.38l-.36-.21-3.78.99 1.01-3.68-.23-.38a9.83 9.83 0 0 1-1.51-5.3C2.14 6.4 6.57 1.97 12.05 1.97a9.8 9.8 0 0 1 6.97 2.89 9.82 9.82 0 0 1 2.89 6.97c0 5.48-4.43 9.97-9.86 9.97Zm5.41-7.45c-.3-.15-1.78-.88-2.05-.98-.27-.1-.47-.15-.67.15-.2.3-.77.98-.94 1.18-.17.2-.35.22-.65.07-.3-.15-1.27-.47-2.42-1.5-.9-.8-1.5-1.79-1.67-2.09-.17-.3-.02-.46.13-.61.14-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.05 1.03-1.05 2.5s1.08 2.9 1.23 3.1c.15.2 2.12 3.24 5.13 4.54.72.31 1.28.49 1.72.63.72.23 1.37.2 1.88.12.58-.09 1.78-.73 2.03-1.43.25-.7.25-1.3.17-1.43-.07-.12-.27-.2-.57-.35Z" />
      </svg>
    ),
  },
  {
    I: Youtube,
    label: "YouTube",
    href: "https://youtube.com",
    color: "from-rose-500 to-red-600",
  },
  {
    I: Instagram,
    label: "Instagram",
    href: "https://instagram.com",
    color: "from-fuchsia-500 to-orange-400",
  },
  {
    I: Facebook,
    label: "Facebook",
    href: "https://facebook.com",
    color: "from-sky-500 to-blue-700",
  },
];

export function SocialSidebar() {
  return (
    <div className="fixed right-3 sm:right-4 top-1/2 -translate-y-1/2 z-40 flex flex-col gap-2">
      {LINKS.map(({ I, label, href, color, icon }) => (
        <a
          key={label}
          href={href}
          target="_blank"
          rel="noreferrer"
          aria-label={label}
          className={`group relative size-10 sm:size-11 rounded-full bg-gradient-to-br ${color} grid place-items-center shadow-lg hover:scale-110 transition`}
        >
          {icon || <I className="size-4 sm:size-5 text-white" />}

          <span className="absolute right-full mr-2 px-2 py-1 rounded-md glass text-[11px] font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition pointer-events-none">
            {label}
          </span>
        </a>
      ))}
    </div>
  );
}