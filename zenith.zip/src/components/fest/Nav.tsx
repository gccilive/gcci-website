import { useEffect, useState } from "react";
import { Menu, X, ChevronDown } from "lucide-react";
import { Link } from "@tanstack/react-router";
import gcciLogo from "@/assets/gcci-logo.webp";
import { withBase } from "@/lib/utils";

const LINKS = [
  ["Principals Conclave", "/principals-conclave"],
  ["Employment Zone", "/employment-zone"],
  ["Podcast Room", "/podcast-room"],
  ["Tech Games", "/#tech-games"],
  ["Volunteer Programme", "/volunteers"],
  ["Sponsors", "/sponsors"],
];

const ABOUT_LINKS = [
  ["About", "/#about"],
  ["Featured Events", "/#events"],
  ["Agenda", "/agenda"],
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 24);
    f();
    window.addEventListener("scroll", f, { passive: true });
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "py-2" : "py-4"
      }`}
    >
      <div className={`mx-auto max-w-7xl px-4 sm:px-6 transition-all ${scrolled ? "" : ""}`}>
        <div className={`flex items-center justify-between rounded-2xl px-4 sm:px-6 py-3 ${
          scrolled ? "glass-strong" : "glass"
        }`}>
          <Link to="/" className="flex items-center gap-3 group">
            <img decoding="async" src={gcciLogo} alt="GCCI" className="h-10 sm:h-11 w-auto" />
            <div className="leading-none">
              <div className="font-display text-2xl sm:text-3xl font-extrabold tracking-wider text-gradient-primary">ZENITH</div>
<div className="text-[10px] sm:text-[11px] text-muted-foreground tracking-[0.22em] mt-0.5">
  GLOBAL YOUTH{" "}
  <span className="text-gradient font-bold">
    TECH &amp; INNOVATION SUMMIT
  </span>{" "}
  · <span className="text-[8px] sm:text-[13px] tracking-[0.15em]">5TH EDITION</span> · 2027
</div>            </div>
          </Link>
          <nav className="hidden xl:flex items-center gap-1">
            <div
              className="relative"
              onMouseEnter={() => setAboutOpen(true)}
              onMouseLeave={() => setAboutOpen(false)}
            >
              <button className="inline-flex items-center gap-1 px-3 py-2 text-[15px] font-semibold text-foreground/85 hover:text-primary transition rounded-md hover:bg-primary/5">
                About <ChevronDown className="size-3.5" />
              </button>
              {aboutOpen && (
                <div className="absolute top-full left-0 mt-1 min-w-[180px] glass-strong border-glow rounded-xl p-2 z-50">
                  {ABOUT_LINKS.map(([l, h]) => (
                    <a key={h} href={withBase(h)} className="block px-3 py-2 text-sm text-foreground/80 hover:text-primary rounded-md hover:bg-primary/5">{l}</a>
                  ))}
                </div>
              )}
            </div>
            {LINKS.map(([l, h]) => (
              <a
                key={h}
                href={withBase(h)}
                className="px-2.5 py-2 text-[15px] font-semibold text-foreground/85 hover:text-primary transition rounded-md hover:bg-primary/5"
              >
                {l}
              </a>
            ))}
            <Link
              to="/awards"
              className="px-3 py-2 text-[15px] font-extrabold rounded-md text-primary animate-blink"
            >
              ★ AWARDS
            </Link>
          </nav>
          <div className="flex items-center gap-2">
            <a
              href={withBase("/#register")}
              className="hidden sm:inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-4 sm:px-5 py-2 text-xs sm:text-sm font-semibold text-primary-foreground glow-sm hover:opacity-95 transition"
            >
              Register
              <span className="hidden sm:inline">→</span>
            </a>
            <button
              aria-label="Menu"
              onClick={() => setOpen(o => !o)}
              className="xl:hidden glass border-glow rounded-full size-9 grid place-items-center"
            >
              {open ? <X className="size-4" /> : <Menu className="size-4" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="xl:hidden mt-2 glass-strong rounded-2xl p-3 grid grid-cols-2 gap-1">
            {ABOUT_LINKS.map(([l, h]) => (
              <a key={h} href={withBase(h)} onClick={() => setOpen(false)}
                 className="px-3 py-2 text-sm font-semibold text-foreground/85 hover:text-primary rounded-md hover:bg-primary/5">
                {l}
              </a>
            ))}
            {LINKS.map(([l, h]) => (
              <a key={h} href={withBase(h)} onClick={() => setOpen(false)}
                 className="px-3 py-2 text-sm font-semibold text-foreground/85 hover:text-primary rounded-md hover:bg-primary/5">
                {l}
              </a>
            ))}
            <Link to="/awards" onClick={() => setOpen(false)}
                  className="px-3 py-2 text-sm font-extrabold text-primary animate-blink">★ AWARDS</Link>
            <a href={withBase("/#register")} onClick={() => setOpen(false)}
               className="px-3 py-2 text-sm font-semibold text-primary">Register →</a>
          </div>
        )}
      </div>
    </header>
  );
}