import { useEffect, useState } from "react";

const TARGET = new Date("2027-01-20T09:00:00+05:30").getTime();

function diff() {
  const d = Math.max(0, TARGET - Date.now());

  return {
    days: Math.floor(d / 86400000),
    hours: Math.floor((d / 3600000) % 24),
    minutes: Math.floor((d / 60000) % 60),
    seconds: Math.floor((d / 1000) % 60),
  };
}

export function Countdown() {
  // Static HTML and the first browser render must be identical, even when
  // the build was generated days before the visitor opens the page.
  const [t, setT] = useState<ReturnType<typeof diff> | null>(null);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | undefined;
    const update = () => {
      if (timer !== undefined) clearInterval(timer);
      timer = undefined;
      if (document.hidden) return;
      setT(diff());
      timer = setInterval(() => setT(diff()), 1000);
    };
    update();
    document.addEventListener("visibilitychange", update);
    return () => {
      if (timer !== undefined) clearInterval(timer);
      document.removeEventListener("visibilitychange", update);
    };
  }, []);

  const items = [
    ["Days", t?.days],
    ["Hours", t?.hours],
    ["Minutes", t?.minutes],
    ["Seconds", t?.seconds],
  ] as const;

  return (
    <div className="grid grid-cols-4 gap-2 sm:gap-2.5">
      {items.map(([label, v]) => (
        <div key={label} className="relative">
          <div className="glass border-glow rounded-lg px-2 py-2.5 sm:px-3 sm:py-3 text-center">
            <div className="font-display text-xl sm:text-2xl font-bold text-gradient tabular-nums">
              {v === undefined ? "--" : String(v).padStart(2, "0")}
            </div>

            <div className="mt-0.5 text-[8px] sm:text-[9px] uppercase tracking-[0.22em] text-muted-foreground">
              {label}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
