import { useEffect, useMemo, useRef, useState } from "react";
import { animateWhenVisible } from "@/lib/decorative-animation";

/**
 * Spherical world-map globe — continent dots projected onto a rotating sphere.
 * Features: 360° rotation, 3-nearest-neighbor mesh, depth fade, pulsing hubs,
 * traveling data arcs, soft rim glow, orbiting particles. No country highlight.
 */

const R = 95;
const RX = -0.35;

// Coarse continent ellipses (lon, lat, lonRadius, latRadius).
const CONTINENTS: [number, number, number, number][] = [
  // North America
  [-100, 48, 28, 16], [-92, 32, 16, 9], [-115, 58, 18, 10], [-78, 48, 12, 9],
  // Central / Caribbean
  [-88, 14, 9, 6],
  // South America
  [-60, -8, 14, 12], [-65, -25, 11, 13], [-70, -42, 6, 10],
  // Greenland
  [-40, 72, 12, 7],
  // Europe
  [12, 50, 20, 9], [25, 60, 16, 7],
  // Africa
  [18, 6, 20, 16], [25, -14, 16, 14], [28, 30, 18, 7],
  // Middle East
  [45, 28, 12, 9],
  // Asia
  [88, 55, 42, 14], [100, 36, 28, 13], [78, 22, 13, 13], [108, 12, 12, 9],
  // Australia / Oceania
  [135, -25, 16, 11], [174, -42, 5, 5],
];

function isLand(lon: number, lat: number) {
  for (const [cl, ca, rl, ra] of CONTINENTS) {
    const dx = (lon - cl) / rl;
    const dy = (lat - ca) / ra;
    if (dx * dx + dy * dy <= 1) return true;
  }
  return false;
}

type P = { x: number; y: number; z: number };

function sampleLandPoints(): P[] {
  const pts: P[] = [];
  const step = 6;
  for (let lat = -78; lat <= 78; lat += step) {
    const cosLat = Math.cos((lat * Math.PI) / 180);
    const lonStep = Math.max(step / Math.max(cosLat, 0.2), step);
    for (let lon = -180; lon < 180; lon += lonStep) {
      if (!isLand(lon, lat)) continue;
      const phi = (lat * Math.PI) / 180;
      const lam = (lon * Math.PI) / 180;
      pts.push({
        x: Math.cos(phi) * Math.cos(lam),
        y: Math.sin(phi),
        z: Math.cos(phi) * Math.sin(lam),
      });
    }
  }
  return pts;
}

function rotateY(p: P, ry: number, rx: number): P {
  const cy = Math.cos(ry), sy = Math.sin(ry);
  const x1 = p.x * cy + p.z * sy;
  const z1 = -p.x * sy + p.z * cy;
  const cx = Math.cos(rx), sx = Math.sin(rx);
  return {
    x: x1,
    y: p.y * cx - z1 * sx,
    z: p.y * sx + z1 * cx,
  };
}

export function Globe() {
  const baseNodes = useMemo(sampleLandPoints, []);

  // Build the mesh using spatial buckets rather than comparing and sorting every
  // point against every other point. This avoids a large main-thread pause on phones.
  const links = useMemo(() => {
    const out: [number, number][] = [];
    const cellSize = 0.24;
    const key = (x: number, y: number, z: number) =>
      `${Math.floor((x + 1) / cellSize)},${Math.floor((y + 1) / cellSize)},${Math.floor((z + 1) / cellSize)}`;
    const buckets = new Map<string, number[]>();
    baseNodes.forEach((p, i) => {
      const k = key(p.x, p.y, p.z);
      const bucket = buckets.get(k);
      if (bucket) bucket.push(i); else buckets.set(k, [i]);
    });
    const seen = new Set<string>();
    for (let i = 0; i < baseNodes.length; i++) {
      const a = baseNodes[i];
      const cx = Math.floor((a.x + 1) / cellSize);
      const cy = Math.floor((a.y + 1) / cellSize);
      const cz = Math.floor((a.z + 1) / cellSize);
      const candidates: { j: number; d: number }[] = [];
      for (let x = cx - 1; x <= cx + 1; x++) for (let y = cy - 1; y <= cy + 1; y++) for (let z = cz - 1; z <= cz + 1; z++) {
        const bucket = buckets.get(`${x},${y},${z}`) || [];
        for (const j of bucket) {
          if (j <= i) continue;
          const b = baseNodes[j];
          const d = (a.x-b.x)**2 + (a.y-b.y)**2 + (a.z-b.z)**2;
          if (d < 0.05) candidates.push({ j, d });
        }
      }
      candidates.sort((a, b) => a.d - b.d);
      for (const candidate of candidates.slice(0, 3)) {
        const pair = `${i}:${candidate.j}`;
        if (!seen.has(pair)) { seen.add(pair); out.push([i, candidate.j]); }
      }
    }
    return out;
  }, [baseNodes]);

  const hubs = useMemo(
    () =>
      // Identical server/client geometry avoids discarding prerendered content.
      Array.from({ length: 12 }, (_, i) =>
        (i * 37 + 17) % baseNodes.length
      ),
    [baseNodes]
  );

  const arcs = useMemo(() => {
    const out: { a: number; b: number; delay: number }[] = [];
    for (let i = 0; i < 8; i++) {
      const a = hubs[i % hubs.length];
      const b = hubs[(i + 5) % hubs.length];
      out.push({ a, b, delay: (i * 0.73) % 4 });
    }
    return out;
  }, [hubs]);

  // Mobile renders the complete globe once; desktop rotates only while visible.
  const [ry, setRy] = useState(0);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;
    return animateWhenVisible(ref.current, (dt) => {
      setRy((v) => (v + dt * 0.0875) % (Math.PI * 2));
    }, 15);
  }, []);

  const rotated = useMemo(
    () => baseNodes.map((p) => rotateY(p, ry, RX)),
    [baseNodes, ry]
  );

  return (
    <div ref={ref} className="globe relative aspect-square w-full max-w-[560px] mx-auto">
      {/* Outer glow halo — orange / pink / blue blend */}
      <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_30%_30%,oklch(0.78_0.18_40/55%),transparent_60%),radial-gradient(circle_at_70%_70%,oklch(0.7_0.22_350/45%),transparent_60%),radial-gradient(circle_at_50%_50%,oklch(0.65_0.18_230/35%),transparent_70%)] blur-3xl" />
      <div className="absolute inset-[-10%] rounded-full bg-[radial-gradient(circle_at_50%_50%,oklch(0.7_0.2_40/22%),transparent_60%)] blur-2xl" />

      {/* Orbit rings */}
      <div
        className="globe-orbit absolute inset-[-4%] rounded-full border border-primary/30"
      >
        <div className="absolute -top-1.5 left-1/2 size-3 rounded-full bg-primary glow-sm" />
      </div>
      <div
        className="globe-orbit globe-orbit-reverse absolute inset-[-12%] rounded-full border border-accent/25"
      >
        <div className="absolute top-1/2 -right-1 size-2 rounded-full bg-accent glow-sm" />
      </div>

      <svg viewBox="-110 -110 220 220" className="absolute inset-0 w-full h-full">
        <defs>
          <radialGradient id="globeBody" cx="38%" cy="35%" r="75%">
            <stop offset="0%" stopColor="oklch(0.98 0.02 60)" />
            <stop offset="55%" stopColor="oklch(0.93 0.05 350)" />
            <stop offset="100%" stopColor="oklch(0.78 0.1 230)" />
          </radialGradient>
          <radialGradient id="globeRim" cx="50%" cy="50%" r="50%">
            <stop offset="80%" stopColor="oklch(0.72 0.2 40)" stopOpacity="0" />
            <stop offset="98%" stopColor="oklch(0.7 0.22 350)" stopOpacity="0.85" />
            <stop offset="100%" stopColor="oklch(0.65 0.18 230)" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="oklch(0.82 0.2 40)" stopOpacity="0.9" />
            <stop offset="100%" stopColor="oklch(0.68 0.22 350)" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="meshGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.7 0.2 40)" />
            <stop offset="50%" stopColor="oklch(0.68 0.22 350)" />
            <stop offset="100%" stopColor="oklch(0.65 0.18 230)" />
          </linearGradient>
          <filter id="softGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="1.2" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <clipPath id="sphereClip">
            <circle cx="0" cy="0" r={R} />
          </clipPath>
        </defs>

        {/* Sphere body */}
        <circle cx="0" cy="0" r={R} fill="url(#globeBody)" />

        <g clipPath="url(#sphereClip)">
          {/* Latitude wireframe */}
          {[-60, -30, 0, 30, 60].map((lat) => {
            const phi = (lat * Math.PI) / 180;
            const pts = Array.from({ length: 48 }, (_, i) => {
              const lon = (i / 48) * Math.PI * 2;
              const r = rotateY(
                {
                  x: Math.cos(phi) * Math.cos(lon),
                  y: Math.sin(phi),
                  z: Math.cos(phi) * Math.sin(lon),
                },
                ry,
                RX
              );
              return { x: r.x * R, y: r.y * R, z: r.z };
            });
            const d = pts
              .map((p, i) => (p.z < -0.05 ? null : `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`))
              .filter(Boolean)
              .join(" ");
            return <path key={`p${lat}`} d={d} fill="none" stroke="oklch(0.7 0.22 22 / 22%)" strokeWidth="0.35" />;
          })}
          {Array.from({ length: 12 }, (_, k) => ((k * Math.PI * 2) / 12)).map((lon, k) => {
            const pts = Array.from({ length: 36 }, (_, i) => {
              const phi = -Math.PI / 2 + (i / 35) * Math.PI;
              const r = rotateY(
                {
                  x: Math.cos(phi) * Math.cos(lon),
                  y: Math.sin(phi),
                  z: Math.cos(phi) * Math.sin(lon),
                },
                ry,
                RX
              );
              return { x: r.x * R, y: r.y * R, z: r.z };
            });
            const d = pts
              .map((p, i) => (p.z < -0.05 ? null : `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`))
              .filter(Boolean)
              .join(" ");
            return <path key={`m${k}`} d={d} fill="none" stroke="oklch(0.7 0.22 22 / 18%)" strokeWidth="0.35" />;
          })}

          {/* Mesh links between nearby land dots */}
          <g filter="url(#softGlow)">
            {links.map(([i, j], k) => {
              const a = rotated[i], b = rotated[j];
              if (a.z < 0 && b.z < 0) return null;
              const depth = (a.z + b.z) / 2;
              const op = Math.max(0, depth) * 0.55 + 0.05;
              return (
                <line
                  key={k}
                  x1={a.x * R}
                  y1={a.y * R}
                  x2={b.x * R}
                  y2={b.y * R}
                  stroke="url(#meshGrad)"
                  strokeWidth={0.3}
                  opacity={op}
                />
              );
            })}
          </g>

          {/* Continent dots */}
          {rotated.map((p, i) => {
            if (p.z < -0.05) return null;
            const isHub = hubs.includes(i);
            const depth = Math.max(0, p.z);
            const r = isHub ? 2.0 + depth * 0.9 : 1.2 + depth * 0.6;
            const palette = ["oklch(0.7 0.2 40)", "oklch(0.68 0.22 350)", "oklch(0.65 0.18 230)"];
            const dotColor = palette[i % 3];
            return (
              <g key={i}>
                {isHub && (
                  <circle
                    cx={p.x * R}
                    cy={p.y * R}
                    r={r * 3.2}
                    fill="url(#nodeGlow)"
                    opacity={0.5 + depth * 0.5}
                  />
                )}
                <circle
                  cx={p.x * R}
                  cy={p.y * R}
                  r={r}
                  fill={isHub ? "oklch(0.85 0.2 40)" : dotColor}
                  opacity={isHub ? 1 : 0.55 + depth * 0.45}
                />
              </g>
            );
          })}

          {/* Pulsing hub rings */}
          {hubs.map((idx, i) => {
            const p = rotated[idx];
            if (!p || p.z < 0) return null;
            return (
              <circle
                key={`pulse-${i}`}
                cx={p.x * R}
                cy={p.y * R}
                fill="none"
                stroke="oklch(0.78 0.2 40)"
                strokeWidth={0.4}
                r={1.5}
                opacity={0.9}
                className="globe-pulse"
                style={{ animationDelay: `${(i * 0.18) % 2.4}s` }}
              />
            );
          })}

          {/* Traveling data arcs */}
          {arcs.map((arc, i) => {
            const a = rotated[arc.a], b = rotated[arc.b];
            if (!a || !b || (a.z < -0.1 && b.z < -0.1)) return null;
            const mx = ((a.x + b.x) / 2) * R;
            const my = ((a.y + b.y) / 2) * R;
            const dist = Math.hypot(a.x - b.x, a.y - b.y);
            const bulge = dist * 40;
            const d = `M${a.x * R},${a.y * R} Q${mx},${my - bulge * 0.35} ${b.x * R},${b.y * R}`;
            return (
              <path
                key={`arc-${i}`}
                d={d}
                fill="none"
                stroke="url(#meshGrad)"
                strokeWidth={0.7}
                strokeLinecap="round"
                pathLength={1}
                opacity={0.6}
                className="globe-arc"
                style={{ animationDelay: `${arc.delay}s` }}
              />
            );
          })}
        </g>

        {/* Rim light */}
        <circle cx="0" cy="0" r={R} fill="url(#globeRim)" />
        {/* Sheen */}
        <ellipse cx="-30" cy="-42" rx="55" ry="35" fill="white" opacity="0.18" />
      </svg>

      {/* Festival title overlay */}
      <div className="pointer-events-none absolute inset-0 grid place-items-center">
        <div className="text-center px-6">
          <div className="text-[11px] sm:text-sm tracking-[0.35em] uppercase text-black font-black drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)]">
            GLOBAL YOUTH
          </div>
          <div className="font-display text-xl sm:text-2xl lg:text-3xl font-extrabold text-gradient-primary leading-tight mt-1 drop-shadow-[0_2px_12px_rgba(255,180,120,0.45)]">
            TECH &amp; INNOVATION<br />SUMMIT
          </div>
          <div className="mt-2 text-sm tracking-[0.35em] uppercase text-black font-black drop-shadow-[0_1px_2px_rgba(255,255,255,0.8)]">
            LUCKNOW · 2027
          </div>
        </div>
      </div>

      {/* Orbiting particles */}
      {Array.from({ length: 16 }).map((_, i) => {
        const angle = (i / 16) * Math.PI * 2;
        const dist = 52 + (i % 3) * 4;
        const x = 50 + Math.cos(angle) * dist;
        const y = 50 + Math.sin(angle) * dist;
        const palette = ["bg-primary", "bg-accent", "bg-destructive"];
        return (
          <span
            key={i}
            className={`globe-particle absolute size-1 rounded-full ${palette[i % 3]}`}
            style={{
              left: `${x}%`, top: `${y}%`, opacity: 0.5,
              animationDuration: `${3 + (i % 4)}s`,
              animationDelay: `${i * 0.15}s`,
            }}
          />
        );
      })}
    </div>
  );
}
