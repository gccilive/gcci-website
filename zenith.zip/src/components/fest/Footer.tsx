import {
  Instagram,
  Linkedin,
  Twitter,
  Youtube,
  MapPin,
  Phone,
  Mail,
  GraduationCap,
  Calendar,
  Users,
} from "lucide-react";
import gcciLogo from "@/assets/gcci-logo.webp";

export function Footer() {
  return (
    <footer className="relative border-t border-border/60 mt-20">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 py-16 grid lg:grid-cols-4 gap-10">
        <div className="lg:col-span-2">
          <div className="flex items-center gap-3">
            <img
              decoding="async"
              src={gcciLogo}
              alt="GCCI"
              loading="eager"
              className="h-12 w-auto"
            />
            <div>
              <div className="font-display text-2xl font-extrabold text-gradient-primary">
                ZENITH
              </div>
              <div className="text-[11px] tracking-[0.22em] text-muted-foreground font-semibold">
                GLOBAL YOUTH{" "}
                <span className="text-gradient font-bold">TECH-FESTIVAL</span> ·
                INDIA 2027
              </div>
            </div>
          </div>
          <p className="mt-5 text-sm text-muted-foreground max-w-md leading-relaxed">
            Where technology shapes the next decade of education & industry.
            Powered by GCCI — Global Chamber of Commerce & Industry.
          </p>
          <form className="mt-6 flex glass border-glow rounded-full p-1 max-w-md">
            <input
              placeholder="your@email.com"
              className="flex-1 bg-transparent px-4 py-2 text-sm outline-none"
            />
            <button className="rounded-full bg-gradient-to-r from-primary to-accent px-5 py-2 text-xs font-semibold text-primary-foreground">
              Subscribe
            </button>
          </form>
          <div className="mt-6 flex gap-3">
            {[Instagram, Linkedin, Twitter, Youtube].map((I, i) => (
              <a
                key={i}
                href="#"
                className="glass border-glow size-10 rounded-full grid place-items-center hover:text-primary transition"
              >
                <I className="size-4" />
              </a>
            ))}
          </div>
        </div>
        <div>
          <div className="text-sm tracking-[0.25em] uppercase text-primary mb-4 font-extrabold">
            Contact
          </div>
          <ul className="space-y-3 text-base text-foreground font-semibold">
            <li className="flex gap-3">
              <MapPin className="size-5 text-primary shrink-0 mt-0.5" />
              <span className="text-lg font-bold">
                Indira Gandhi Pratishthan, Lucknow
              </span>
            </li>

            <li className="flex gap-3">
              <Phone className="size-4 text-primary shrink-0 mt-0.5" />
              <span>
                +91 5732413499
                <br />
                +91 9411 400 557
                <br />
                +60 17 926 5131
              </span>
            </li>

            <li className="flex gap-3">
              <Mail className="size-4 text-primary shrink-0 mt-0.5" />
              <span>
                info@gcci.live
                <br />
                gccimalaysia@gcci.live
              </span>
            </li>

            <li className="flex gap-3">
              <GraduationCap className="size-4 text-primary shrink-0 mt-0.5" />
              <a
                href="https://www.gcci.live/education"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary transition-colors"
              >
                www.gcci.live/education
              </a>
            </li>
          </ul>
        </div>
        <div>
          <div className="text-sm tracking-[0.25em] uppercase text-primary mb-4 font-extrabold">
            Event
          </div>
          <ul className="space-y-3 text-base text-foreground font-semibold">
            <li className="flex gap-3">
              <Calendar className="size-4 text-primary shrink-0 mt-0.5" />
              <span className="font-bold">20th, 21st, 22nd January 2027</span>
            </li>
            <li className="flex gap-3">
              <MapPin className="size-4 text-primary shrink-0 mt-0.5" />
              <span className="font-bold">
                Indira Gandhi Pratishthan, Lucknow
              </span>
            </li>
            <li className="flex gap-3">
              <Users className="size-4 text-primary shrink-0 mt-0.5" />
              <span>10,000 attendees · 20+ countries</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-border/60 py-6 text-center text-xs text-muted-foreground">
        © 2027 Zenith · Global Youth{" "}
        <span className="text-gradient font-bold">Tech-Festival</span> India ·
        An initiative by GCCI
      </div>
    </footer>
  );
}
