import { useEffect, useRef } from "react";
import { animateWhenVisible } from "@/lib/decorative-animation";

export function Particles() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    let dpr = 1;
    let points: { x: number; y: number; vx: number; vy: number; r: number }[] =
      [];
    const draw = (dt = 0) => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const point of points) {
        point.x += point.vx * dt * 60;
        point.y += point.vy * dt * 60;
        if (point.x < 0 || point.x > canvas.width) point.vx *= -1;
        if (point.y < 0 || point.y > canvas.height) point.vy *= -1;
        ctx.fillStyle = "oklch(0.7 0.22 22 / 0.6)";
        ctx.beginPath();
        ctx.arc(point.x, point.y, point.r, 0, Math.PI * 2);
        ctx.fill();
      }
      for (let i = 0; i < points.length; i++) {
        for (let j = i + 1; j < points.length; j++) {
          const a = points[i],
            b = points[j];
          const distance = Math.hypot(a.x - b.x, a.y - b.y);
          if (distance >= 140 * dpr) continue;
          ctx.strokeStyle = `oklch(0.62 0.21 25 / ${0.18 * (1 - distance / (140 * dpr))})`;
          ctx.lineWidth = 0.6;
          ctx.beginPath();
          ctx.moveTo(a.x, a.y);
          ctx.lineTo(b.x, b.y);
          ctx.stroke();
        }
      }
    };
    const resize = () => {
      const mobile = window.innerWidth < 768;
      dpr = Math.min(window.devicePixelRatio || 1, mobile ? 1 : 1.5);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      points = Array.from({ length: mobile ? 18 : 42 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3 * dpr,
        vy: (Math.random() - 0.5) * 0.3 * dpr,
        r: (Math.random() * 1.4 + 0.4) * dpr,
      }));
      // Keep the same particle backdrop on phones without a continuous loop.
      draw();
    };
    resize();
    const stop = animateWhenVisible(canvas, draw);
    window.addEventListener("resize", resize, { passive: true });
    return () => {
      stop();
      window.removeEventListener("resize", resize);
    };
  }, []);
  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="absolute inset-0 w-full h-full pointer-events-none opacity-60"
    />
  );
}
