import { Globe } from "./Globe";
import { Particles } from "./Particles";
import { Countdown } from "./Countdown";
import { ArrowRight, Play } from "lucide-react";

export function Hero() {
  return (
    <section id="top" className="relative min-h-screen pt-28 pb-0 overflow-hidden bg-hero">
      <div className="absolute inset-0 grid-bg" />
      <div className="absolute inset-0 mesh-bg animate-aurora pointer-events-none" />
      <div className="absolute inset-0 noise-bg" />
      <Particles />

      {/* glow blobs */}
      <div className="absolute -top-32 -left-24 size-[520px] rounded-full bg-primary/25 blur-[140px]" />
      <div className="absolute bottom-0 right-0 size-[460px] rounded-full bg-accent/25 blur-[140px]" />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 size-[360px] rounded-full bg-destructive/15 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-12 pb-20">
        {/* Main editorial grid */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-10 items-start mt-4 lg:mt-8">

          {/* Left column: title + lead */}
          <div className="lg:col-span-7 lg:col-start-1 lg:row-start-1 min-w-0">
            <h1
              className="headline-xl"
            >
<span className="block mb-0">
  <span className="inline-block rounded-full px-4 py-1.5 bg-gradient-to-r from-primary via-accent to-destructive text-primary-foreground font-mono text-[11px] sm:text-sm tracking-[0.32em] uppercase font-extrabold glow shadow-lg animate-pulse">
    20<sup>th</sup>, 21<sup>st</sup>, 22<sup>nd</sup> January 2027
  </span>
</span>

<span className="block -mt-2 sm:-mt-15 mb-0 leading-none">
  <span className="inline-block font-mono text-[12px] sm:text-[17px] tracking-[0.18em] sm:tracking-[0.28em] uppercase font-bold text-foreground/70 leading-none">
    Education Council of GCCI Presents
  </span>
</span>

<span className="block !mt-0 leading-none chrome-text">
  ZENITH
</span>

              <span className="block mt-5">
                <span className="inline-block font-display italic font-black tracking-tight text-[0.34em] bg-gradient-to-r from-primary via-accent to-destructive bg-clip-text text-transparent drop-shadow-[0_2px_18px_rgba(255,90,40,0.35)]">
                  Global&nbsp;Youth
                </span>
              </span>

<span className="block text-gradient-primary text-glitch text-[0.5em] leading-[0.95] mt-2">
  TECH &amp; INNOVATION
  <br />
  SUMMIT{" "}
  <span className="text-[0.38em] tracking-[0.18em] align-middle">
    5TH EDITION
  </span>
</span>
            </h1>
                      {/* Sub-meta strip under title — full-width grid row */}
            <div
              className="lg:col-span-12 mt-7 flex flex-wrap items-center gap-x-5 gap-y-2 font-mono text-base sm:text-lg lg:text-xl tracking-[0.28em] uppercase text-foreground font-extrabold min-w-0"
            >
              <span className="font-black text-foreground drop-shadow">
                INDIRA GANDHI PRATISHTHAN, LUCKNOW
              </span>





              <span className="text-gradient-primary font-black drop-shadow">
                20<sup>th</sup>, 21<sup>st</sup>, 22<sup>nd</sup> JANUARY 2027
              </span>
            </div>
          </div>



            {/* Full-width introduction: positioned directly after venue/date and allowed to wrap on every screen size. */}
            <div className="lg:col-span-12 relative mt-8 w-full min-w-0 max-w-full space-y-4 break-words [overflow-wrap:anywhere]">
              <p className="w-full min-w-0 max-w-full text-base sm:text-lg lg:text-xl leading-relaxed text-foreground/85">
                Today's students are the <strong className="text-foreground font-semibold">architects of tomorrow's world</strong>. Three cinematic days where 10,000 attendees, 20+ speakers, and 200+ exhibitors from <strong className="text-foreground font-semibold">20+ countries</strong> converge to shape the next decade of education, AI, and human possibility.
              </p>
              <p className="w-full min-w-0 max-w-full text-base sm:text-lg leading-relaxed text-foreground/80">
                Zenith focuses on cross-border collaboration, future-defining technologies, and digital creativity. To engage a massive global audience of Gen Z and Gen Alpha innovators, developers, and creators, the festival must blend high-intensity technical competition with youth culture, gaming, and sustainability.
              </p>
            </div>

          {/* Continue the left column content after the full-width introduction. */}
          <div className="lg:col-span-7 lg:col-start-1 min-w-0">
            {/* Code. Create. Collaborate. Change. — themed manifesto strip */}
            <div
              className="mt-7 relative rounded-2xl overflow-hidden border-2 border-transparent bg-[linear-gradient(90deg,oklch(0.18_0.05_300/0.6),oklch(0.18_0.08_20/0.55))] p-[1px]"
            >
              <div className="rounded-2xl bg-background/60 backdrop-blur-md px-5 py-3 flex flex-wrap items-center gap-x-5 gap-y-2 justify-between">
                {[
                  ["Code", "from-cyan-400 to-blue-500"],
                  ["Create", "from-fuchsia-400 to-pink-500"],
                  ["Collaborate", "from-amber-400 to-orange-500"],
                  ["Change", "from-emerald-400 to-teal-500"],
                ].map(([w, g]) => (
                  <span
                    key={w}
                    className={`font-display text-xl sm:text-2xl font-extrabold tracking-tight bg-gradient-to-r ${g} bg-clip-text text-transparent drop-shadow`}
                  >
                    {w}
                    <span className="text-foreground/40">.</span>
                  </span>
                ))}
              </div>
            </div>

            <div
              className="mt-8 flex flex-wrap gap-3"
            >
              <a
                href="#register"
                className="group relative inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-7 py-3.5 text-sm font-semibold text-primary-foreground glow hover:scale-[1.02] transition"
              >
                Reserve Your Pass
                <ArrowRight className="size-4 group-hover:translate-x-1 transition" />
              </a>

              <a
                href="#about"
                className="inline-flex items-center gap-2 glass border-glow rounded-full px-6 py-3.5 text-sm font-semibold hover:text-primary transition"
              >
                <Play className="size-4" /> Watch Sizzle
              </a>
            </div>

            {/* Inline stat row */}
            <div
              className="mt-10 grid grid-cols-3 max-w-md"
            >
              {[
                ["20+", "Countries"],
                ["10,000", "Attendees"],
                ["3", "Days"],
              ].map(([n, l], i) => (
                <div
                  key={l}
                  className={`px-4 ${
                    i > 0 ? "border-l border-border/60" : ""
                  }`}
                >
                  <div className="font-hero text-2xl sm:text-3xl font-extrabold text-gradient leading-none">
                    {n}
                  </div>

                  <div className="mt-1.5 font-mono text-[10px] tracking-[0.28em] uppercase text-muted-foreground">
                    {l}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right column: globe + countdown card */}
          <div className="lg:col-span-5 lg:col-start-8 lg:row-start-1 relative min-w-0">
            <div
              className="relative"
            >
              <div className="animate-float">
                <Globe />
              </div>
            </div>

            <div
              className="mt-6 glass-strong border-glow rounded-2xl p-5"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="kicker text-primary">
                  Curtain Rises
                </div>

                <div className="font-mono text-[10px] tracking-[0.32em] uppercase text-muted-foreground">
                  T-Minus
                </div>
              </div>

              <Countdown />
            </div>
          </div>
        </div>
      </div>

      {/* Marquee ticker at the bottom of hero */}
      <div className="relative border-y border-border/60 bg-background/60 backdrop-blur-sm">
        <div className="overflow-hidden">
          <div className="flex gap-10 w-max animate-marquee py-3 font-mono text-[11px] tracking-[0.32em] uppercase">
            {Array.from({ length: 2 }).map((_, k) => (
              <div
                key={k}
                className="flex items-center gap-10 pr-10"
              >
                {[
                  "Zenith / 2027",
                  "AI · Robotics · Cyber · Space",
                  "8 Arenas · 1 Stage",
                  "10,000 Attendees",
                  "20+ Countries",
                  "Golden Book of Education Awards",
                  "Hackathon · 100+ Builders",
                  "Principals Conclave",
                  "Gala DJ Night · 22 Jan",
                ].map((t, i) => (
                  <span
                    key={i}
                    className="flex items-center gap-10"
                  >
                    <span
                      className={
                        i % 2 === 0
                          ? "text-gradient-primary font-semibold"
                          : "text-foreground/80"
                      }
                    >
                      {t}
                    </span>

                    <span className="text-primary/60">
                      ◆
                    </span>
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

