import { SectionHeader } from "./SectionHeader";
import { CarouselStrip } from "./CarouselStrip";
import { m as motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import {
  Brain, Cpu, Bot, Gamepad2, Rocket, Shield, Plane, Lightbulb,
  MapPin, Mail, Phone, Calendar, Users, Award, Globe2,
  Instagram, Linkedin, Twitter, Youtube, Plus, Minus, ChevronRight,
  CheckCircle2, Loader2, Sparkles, AlertCircle, Trophy, Joystick, Camera, X, ArrowLeft,
  BookMarked, Play,
  GraduationCap,
} from "lucide-react";
import goldenBookVideo from "@/assets/golden-book.mp4";
import goldenBookPoster from "@/assets/golden-book-poster.webp";
import { Link } from "@tanstack/react-router";
import { withBase } from "@/lib/utils";
import techSectors from "@/assets/tech-sectors-v2.webp";
import galaDj from "@/assets/gala-dj.webp";
import musicalNight from "@/assets/musical-night.webp";
import fragmentsNight from "@/assets/fragments-night.webp";
import pmmodi from "@/assets/pm-modi.webp";
import yogi from "@/assets/yogi.webp";
import yogi1 from "@/assets/yogi2.webp";
import aiWeek from "@/assets/ai-week.webp";
import cyberWeek from "@/assets/cyber-week.webp";
import gov1 from "@/assets/gov-logo-1.webp";
import gov2 from "@/assets/gov-logo-2.webp";
import gov3 from "@/assets/gov-logo-3.webp";
import gov4 from "@/assets/gov-logo-4.webp";
import gov5 from "@/assets/gov-logo-5.webp";
import gov6 from "@/assets/gov-logo-6.webp";
import gov7 from "@/assets/gov-logo-7.webp";
import youthFest1_01 from "@/assets/youth-fest-1/01.webp";
import youthFest1_02 from "@/assets/youth-fest-1/02.webp";
import youthFest1_03 from "@/assets/youth-fest-1/03.webp";
import youthFest1_04 from "@/assets/youth-fest-1/04.webp";
import youthFest1_05 from "@/assets/youth-fest-1/05.webp";
import youthFest1_06 from "@/assets/youth-fest-1/06.webp";
import youthFest1_07 from "@/assets/youth-fest-1/07.webp";
import youthFest1_08 from "@/assets/youth-fest-1/08.webp";
import youthFest1_09 from "@/assets/youth-fest-1/09.webp";
import youthFest1_10 from "@/assets/youth-fest-1/10.webp";
import youthFest1_11 from "@/assets/youth-fest-1/11.webp";
import youthFest1_12 from "@/assets/youth-fest-1/12.webp";
import youthFest1_13 from "@/assets/youth-fest-1/13.webp";
import youthFest1_14 from "@/assets/youth-fest-1/14.webp";
import youthFest1_15 from "@/assets/youth-fest-1/15.webp";
import youthFest2_01 from "@/assets/youth-fest-2/01.webp";
import youthFest2_02 from "@/assets/youth-fest-2/02.webp";
import youthFest2_03 from "@/assets/youth-fest-2/03.webp";
import youthFest2_04 from "@/assets/youth-fest-2/04.webp";
import youthFest2_05 from "@/assets/youth-fest-2/05.webp";
import youthFest2_07 from "@/assets/youth-fest-2/07.webp";
import youthFest2_08 from "@/assets/youth-fest-2/08.webp";
import youthFest2_09 from "@/assets/youth-fest-2/09.webp";
import youthFest2_10 from "@/assets/youth-fest-2/10.webp";
import youthFest2_11 from "@/assets/youth-fest-2/11.webp";
import youthFest2_12 from "@/assets/youth-fest-2/12.webp";
/* ---------- Nights showcase ---------- */
export function Nights() {
  return (
    <section id="nights" className="relative py-28 px-4 sm:px-6 overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="absolute -top-32 left-1/3 size-[480px] rounded-full bg-accent/25 blur-[140px]" />
      <div className="absolute -bottom-32 right-1/4 size-[420px] rounded-full bg-primary/25 blur-[140px]" />

      <div className="relative mx-auto max-w-7xl">
        <SectionHeader
          kicker="After-Dark Headliners"
          title="Zenith Nights"
          sub="When the keynotes end, the stadium ignites. Three unforgettable nights — opening with melody, a student showcase mid-festival, and closing with mayhem."
        />

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {/* Musical Night */}
          <a
            href="#register"
            className="hover-lift-6 group relative block rounded-3xl overflow-hidden border-glow glass-strong"
          >
            <div className="absolute top-4 left-4 z-10 inline-flex items-center gap-2 rounded-full bg-background/70 backdrop-blur px-3 py-1.5 text-[10px] font-bold tracking-[0.25em] uppercase text-primary">
              <Calendar className="size-3" /> Day 01 · 20 January
            </div>
            <div className="relative aspect-[2/3] overflow-hidden">
              <img decoding="async"
                src={musicalNight}
                alt="Musical Night — Opening Ceremony Live Concert, 20 January 2027, Indira Gandhi Pratishthan"
                width={1024}
                height={1536}
                loading="lazy"
                className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />
            </div>
            <div className="relative p-6 sm:p-8">
              <div className="text-[10px] tracking-[0.3em] uppercase text-primary font-bold">Opening Night</div>
              <h3 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-gradient-primary">Musical Night</h3>
              <p className="mt-3 text-sm sm:text-base text-foreground/80 leading-relaxed font-medium">
                A live concert curtain-raiser. Indie headliners, surprise guest performers, an arena lit in gold and rose — the soundtrack that opens Zenith 2027.
              </p>
              <div className="mt-5 flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="size-3.5 text-primary" /> Indira Gandhi Pratishthan · Main Arena · 7:30 PM onwards
              </div>
              <div className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-primary group-hover:gap-3 transition-all">
                Reserve your seat <ChevronRight className="size-4" />
              </div>
            </div>
          </a>

          {/* Fragments of Genius Night */}
          <a
            href="#register"
            className="hover-lift-6 group relative block rounded-3xl overflow-hidden border-glow glass-strong"
          >
            <div className="absolute top-4 left-4 z-10 inline-flex items-center gap-2 rounded-full bg-background/70 backdrop-blur px-3 py-1.5 text-[10px] font-bold tracking-[0.25em] uppercase text-primary">
              <Calendar className="size-3" /> Day 02 · 21 January
            </div>
            <div className="relative aspect-[2/3] overflow-hidden">
              <img decoding="async"
                src={fragmentsNight}
                alt="Fragments of Genius Night — Student performances from schools and colleges, 21 January 2027, Indira Gandhi Pratishthan"
                width={1024}
                height={1536}
                loading="lazy"
                className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />
            </div>
            <div className="relative p-6 sm:p-8">
              <div className="text-[10px] tracking-[0.3em] uppercase text-primary font-bold">Student Showcase</div>
              <h3 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-gradient">Fragments of Genius</h3>
              <p className="mt-3 text-sm sm:text-base text-foreground/80 leading-relaxed font-medium">
                A spotlit evening of music, dance, drama and poetry — performed entirely by students of schools and colleges. Young minds, bold stage, infinite possibilities.
              </p>
              <div className="mt-5 flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="size-3.5 text-primary" /> Indira Gandhi Pratishthan · Open Theatre · 7:00 PM onwards
              </div>
              <div className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-primary group-hover:gap-3 transition-all">
                Get your pass <ChevronRight className="size-4" />
              </div>
            </div>
          </a>

          {/* Gala DJ Night - featured */}
          <a
            href="#register"
            className="hover-lift-6 group relative block rounded-3xl overflow-hidden border-glow glass-strong md:scale-[1.02]"
          >
            <div className="absolute -inset-px rounded-3xl bg-gradient-to-br from-primary/40 via-accent/30 to-primary/40 opacity-60 blur-2xl pointer-events-none" />
            <div className="absolute top-4 left-4 z-10 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-3 py-1.5 text-[10px] font-extrabold tracking-[0.25em] uppercase text-primary-foreground animate-pulse-glow">
              <Sparkles className="size-3" /> Grand Finale
            </div>
            <div className="absolute top-4 right-4 z-10 inline-flex items-center gap-2 rounded-full bg-background/70 backdrop-blur px-3 py-1.5 text-[10px] font-bold tracking-[0.25em] uppercase text-foreground">
              <Calendar className="size-3 text-primary" /> Day 03 · 22 January
            </div>
            <div className="relative aspect-[2/3] overflow-hidden">
              <img decoding="async"
                src={galaDj}
                alt="Gala DJ Night — Zenith Closing Party, 22 January 2027, Indira Gandhi Pratishthan"
                width={1024}
                height={1536}
                loading="lazy"
                className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/10 to-transparent" />
            </div>
            <div className="relative p-6 sm:p-8">
              <div className="text-[10px] tracking-[0.3em] uppercase text-primary font-bold animate-blink">★ Closing Night Spectacle</div>
              <h3 className="mt-2 font-display text-3xl sm:text-4xl font-extrabold text-gradient">Gala DJ Night</h3>
              <p className="mt-3 text-sm sm:text-base text-foreground/80 leading-relaxed font-medium">
                Lasers, confetti cannons, world-class DJs and 10,000 voices — the official Zenith afterparty that turns Indira Gandhi Pratishthan into one giant dance floor.
              </p>
              <div className="mt-5 flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="size-3.5 text-primary" /> Indira Gandhi Pratishthan · Sky Arena · 9:00 PM till late
              </div>
              <div className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-5 py-2.5 text-sm font-bold text-primary-foreground glow-sm group-hover:scale-[1.03] transition">
                Grab your wristband <ChevronRight className="size-4" />
              </div>
            </div>
          </a>
        </div>
      </div>
    </section>
  );
}

/* ---------- shared ---------- */
function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  return <span>{to.toLocaleString("en-US")}{suffix}</span>;
}

export function About() {
  const stats = [
    { v: 3, s: "", l: "Immersive Days" },
    { v: 20, s: "+", l: "Global Speakers" },
    { v: 200, s: "+", l: "Exhibitors" },
    { v: 10000, s: "", l: "Attendees" },
  ];

  return (
    <section
      id="about"
      className="relative py-20 sm:py-24 lg:py-28 px-4 sm:px-6"
    >
      <div className="mx-auto max-w-7xl">

        {/* =====================================================
            TOP IMAGES — PM MODI + YOGI
        ====================================================== */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mb-16 lg:mb-20">

          {/* =================================================
              PM MODI
          ================================================== */}
          <div
            className="relative rounded-[2rem] p-[2px] overflow-hidden"
          >
            <div
              className="
                absolute inset-0
                rounded-[2rem]
                bg-gradient-to-br
                from-primary/50
                via-accent/30
                to-destructive/40
              "
            />

            <div className="relative rounded-[2rem] bg-white/90 overflow-hidden p-2">

              <div
                className="
                  w-full
                  h-[420px]
                  sm:h-[500px]
                  lg:h-[560px]
                  rounded-[1.5rem]
                  overflow-hidden
                  bg-white
                  flex
                  items-center
                  justify-center
                "
              >
                <img decoding="async"
                  src={pmmodi}
                  alt="Prime Minister Narendra Modi"
                  className="
                    w-full
                    h-full
                    object-contain
                    transition-transform
                    duration-700
                    hover:scale-[1.015]
                  "
                  loading="lazy"
                />
              </div>

            </div>
          </div>


          {/* =================================================
              YOGI
          ================================================== */}
          <div
            className="relative rounded-[2rem] p-[2px] overflow-hidden"
          >
            <div
              className="
                absolute inset-0
                rounded-[2rem]
                bg-gradient-to-br
                from-accent/50
                via-primary/30
                to-destructive/40
              "
            />

            <div className="relative rounded-[2rem] bg-white/90 overflow-hidden p-2">

              <div
                className="
                  w-full
                  h-[420px]
                  sm:h-[500px]
                  lg:h-[560px]
                  rounded-[1.5rem]
                  overflow-hidden
                  bg-white
                  flex
                  items-center
                  justify-center
                "
              >
                <img decoding="async"
                  src={yogi}
                  alt="Yogi Adityanath"
                  className="
                    w-full
                    h-full
                    object-contain
                    transition-transform
                    duration-700
                    hover:scale-[1.015]
                  "
                  loading="lazy"
                />
              </div>

            </div>
          </div>

        </div>


        {/* =====================================================
            YOGI 1 — NARROWER + PROPER PROPORTION
        ====================================================== */}
        <div
          className="relative w-full mb-14 lg:mb-16"
        >

          {/* Centered narrower card */}
          <div className="relative mx-auto w-full max-w-4xl">

            {/* Gradient Border */}
            <div
              className="
                absolute
                inset-0
                rounded-[2rem]
                bg-gradient-to-br
                from-primary/50
                via-accent/30
                to-destructive/40
              "
            />

            <div
              className="
                relative
                w-full
                rounded-[2rem]
                bg-white
                overflow-hidden
                p-2
              "
            >

              {/* =================================================
                  YOGI 1 IMAGE
              ================================================== */}
              <div
                className="
                  w-full
                  h-[450px]
                  sm:h-[600px]
                  lg:h-[720px]
                  rounded-[1.5rem]
                  overflow-hidden
                  bg-white
                "
              >
                <img decoding="async"
                  src={yogi1}
                  alt="Yogi Adityanath"
                  className="
                    block
                    w-full
                    h-full
                    object-fill
                    transition-transform
                    duration-700
                    hover:scale-[1.01]
                  "
                  loading="lazy"
                />
              </div>

            </div>
          </div>

        </div>


        {/* =====================================================
            ABOUT + STATS
        ====================================================== */}
        <div
          className="
            grid
            grid-cols-1
            lg:grid-cols-2
            gap-10
            lg:gap-14
            items-stretch
          "
        >

          {/* =================================================
              LEFT — ABOUT CONTENT
          ================================================== */}
          <div
            className="w-full"
          >

            {/* LABEL */}
            <div className="text-xs sm:text-sm tracking-[0.3em] uppercase text-primary mb-5 font-bold">
              About Zenith
            </div>


            {/* HEADING */}
            <h2
              className="
                font-display
                text-4xl
                sm:text-5xl
                lg:text-5xl
                xl:text-6xl
                font-extrabold
                leading-[1.08]
              "
            >
              Where{" "}
              <span className="text-gradient-primary">
                Technology
              </span>{" "}
              Shapes The Next Decade Of Education & Industry.
            </h2>


            {/* DESCRIPTION */}
            <p className="mt-7 text-foreground/80 text-lg leading-relaxed">
              Global Youth{" "}
              <span className="text-gradient font-bold">
                Tech-Festival
              </span>{" "}
              India 2027 —
              <span className="text-gradient-primary font-extrabold">
                {" "}ZENITH
              </span>{" "}
              — unites pioneers, students, founders and policy makers for
              Three cinematic days (
              <span className="text-foreground font-bold">
                20th, 21st, 22nd January 2027
              </span>
              ) at the
              <span className="text-foreground font-bold">
                {" "}Indira Gandhi Pratishthan, Lucknow
              </span>
              . Three stages, six tracks, infinite collisions of code,
              capital and curiosity.
            </p>


            {/* =================================================
                VISION + MISSION
            ================================================== */}
            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-4">

              {/* VISION */}
              <div className="relative rounded-2xl p-[2px]">

                <div
                  className="
                    absolute inset-0
                    rounded-2xl
                    bg-gradient-to-r
                    from-primary
                    to-accent
                    opacity-80
                    blur-[2px]
                  "
                />

                <div
                  className="
                    relative
                    rounded-2xl
                    p-5
                    sm:p-6
                    bg-white/80
                    backdrop-blur-xl
                    border
                    border-white/60
                    min-h-[140px]
                    flex
                    flex-col
                    justify-center
                  "
                >
                  <div className="text-xs tracking-[0.3em] uppercase font-extrabold text-primary">
                    ★ Vision
                  </div>

                  <p className="mt-3 text-base sm:text-lg text-foreground font-bold leading-snug">
                    A world where every young mind has frontier-grade tools.
                  </p>
                </div>

              </div>


              {/* MISSION */}
              <div className="relative rounded-2xl p-[2px]">

                <div
                  className="
                    absolute inset-0
                    rounded-2xl
                    bg-gradient-to-r
                    from-accent
                    to-destructive
                    opacity-80
                    blur-[2px]
                  "
                />

                <div
                  className="
                    relative
                    rounded-2xl
                    p-5
                    sm:p-6
                    bg-white/80
                    backdrop-blur-xl
                    border
                    border-white/60
                    min-h-[140px]
                    flex
                    flex-col
                    justify-center
                  "
                >
                  <div className="text-xs tracking-[0.3em] uppercase font-extrabold text-accent">
                    ★ Mission
                  </div>

                  <p className="mt-3 text-base sm:text-lg text-foreground font-bold leading-snug">
                    Spark 1M+ youth-led innovations by 2030.
                  </p>
                </div>

              </div>

            </div>

          </div>


          {/* =================================================
              RIGHT — 4 STAT CARDS
          ================================================== */}
          <div
            className="w-full flex items-center"
          >

            <div className="w-full">

              <div
                className="
                  grid
                  grid-cols-2
                  gap-4
                  sm:gap-5
                  w-full
                "
              >

                {stats.map((s, i) => (
                  <div
                    key={s.l}
                    className="hover-lift-4 
                      relative
                      overflow-hidden
                      rounded-2xl
                      h-[145px]
                      sm:h-[165px]
                      p-5
                      sm:p-6
                      bg-white/80
                      backdrop-blur-xl
                      border
                      border-primary/25
                      shadow-md
                      text-left
                      flex
                      flex-col
                      justify-center
                    "
                  >

                    {/* Decorative Glow */}
                    <div
                      className="
                        absolute
                        -right-7
                        -top-7
                        w-24
                        h-24
                        rounded-full
                        bg-primary/15
                        blur-2xl
                      "
                    />

                    {/* NUMBER */}
                    <div
                      className="
                        relative
                        font-display
                        text-3xl
                        sm:text-4xl
                        font-bold
                        text-gradient
                      "
                    >
                      <Counter
                        to={s.v}
                        suffix={s.s}
                      />
                    </div>

                    {/* LABEL */}
                    <div
                      className="
                        relative
                        mt-2
                        text-sm
                        sm:text-base
                        text-foreground
                        font-medium
                      "
                    >
                      {s.l}
                    </div>

                  </div>
                ))}

              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
/* ---------- Embassies of Innovation ---------- */
export function EmbassiesOfInnovation() {
  return (
    <section id="embassies-of-innovation" className="relative overflow-hidden py-20 px-4 sm:px-6">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10" />
      <div className="relative mx-auto max-w-6xl">
        <div className="mx-auto max-w-4xl text-center mb-10">
          <div className="kicker justify-center text-primary">Global Partnerships · Youth Diplomacy</div>
          <h2 className="mt-4 font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold leading-tight text-gradient">
            Embassies of Innovation: Global Tech Exposure and Diplomatic Engagement
          </h2>
          <p className="mt-5 text-lg sm:text-xl leading-relaxed text-foreground/85">
            <em className="font-semibold text-foreground">Embassies of Innovation</em> will serve as a dedicated initiative to connect young leaders with international embassies, technology hubs, innovation centres, and global knowledge networks.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-5 lg:gap-6">
          {[
            { title: "Global Exposure Visits", text: "With active involvement from embassies, participants will take part in exposure visits, interactive dialogues, and knowledge-exchange sessions introducing them to global advancements in technology, entrepreneurship, artificial intelligence, digital transformation, and sustainable innovation.", icon: Globe2 },
            { title: "Dialogue with Global Experts", text: "Through embassy-led engagements, youth delegates will have opportunities to interact with diplomats, technology experts, entrepreneurs, and innovation ecosystem representatives.", icon: Users },
            { title: "International Best Practices", text: "Participants will gain insights into international best practices, cross-border collaboration, and emerging opportunities for youth-led innovation.", icon: Lightbulb },
            { title: "Lasting Global Collaboration", text: "This platform will support sustained engagement between embassies and young innovators, strengthening international partnerships and creating pathways for knowledge exchange, technology exposure, and youth-led global collaboration.", icon: Sparkles },
          ].map((item) => (
            <article key={item.title} className="glass border-glow rounded-2xl p-6 sm:p-7 h-full">
              <div className="mb-4 inline-flex size-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 text-primary">
                <item.icon className="size-6" />
              </div>
              <h3 className="font-display text-xl sm:text-2xl font-bold">{item.title}</h3>
              <p className="mt-3 text-sm sm:text-base leading-relaxed text-foreground/80">{item.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Something Extraordinary ---------- */
export function ExtraordinaryYouthEngagement() {
  const initiatives = [
    { title: "Global Youth Council Panels", text: "Structured debates where young founders, open-source contributors, and digital activists under 25 discuss tech ethics, AI governance, and internet freedom.", tag: "Leadership & policy" },
    { title: "Quantum Sandbox", text: "Simplified, gamified visualizations of quantum computing principles where participants can run basic algorithms on simulated quantum hardware.", tag: "Quantum computing" },
    { title: "AI Creative Lab", text: "Spaces dedicated to GenAI tools where youth can join live prompt-off battles, generate short films, edit synthetic music tracks, or fine-tune open-source LLMs live.", tag: "Generative AI" },
    { title: "Biotech & Green Innovation Arena", text: "Interactive exhibits at the intersection of code and biology, featuring student-led projects on DNA data storage, biodegradable computing hardware, and smart IoT carbon trackers.", tag: "Climate & biotech" },
    { title: "The “Borderlands” Mega-Hackathon", text: "A 48-hour hybrid hackathon where local attendees are randomly paired with international developers via video links to solve global challenges such as climate technology and disaster-relief apps.", tag: "48-hour challenge" },
    { title: "Decentralized Creator Economy Hub", text: "Workshops on building micro-economies, understanding smart contracts, and using blockchain securely for digital art, music royalties, and fan engagement.", tag: "Creator economy" },
    { title: "Digital Art Gallery & Projection Mapping", text: "A curated gallery of generative AI art, interactive digital sculptures, and real-time algorithmic music visualizations mapped across venue walls.", tag: "Art & immersive media" },
    { title: "Remote Work & Digital Nomad Kiosks", text: "Booths representing decentralized organizations, global freelance networks, and remote-first technology companies hiring global entry-level talent.", tag: "Future of work" },
  ];

  return (
    <section className="relative overflow-hidden py-20 px-4 sm:px-6">
      <div className="pointer-events-none absolute -top-24 right-0 size-80 rounded-full bg-accent/15 blur-3xl" />
      <div className="relative mx-auto max-w-7xl">
        <SectionHeader
          kicker="The Next Wave of Youth Innovation"
          title="Something Extraordinary Is Happening!"
          sub="A historic development in youth engagement—where technology, creativity, global collaboration, and real-world challenges meet."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {initiatives.map((item, index) => (
            <article
              key={item.title}
              className="group relative h-full overflow-hidden rounded-2xl glass border-glow p-6"
            >
              <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary via-accent to-destructive" />
              <div className="text-[10px] uppercase tracking-[0.2em] text-primary font-bold">{item.tag}</div>
              <h3 className="mt-3 font-display text-xl font-extrabold leading-snug">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-foreground/80">{item.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Events ---------- */
const EVENTS = [
  { icon: Brain, name: "AI Battles", desc: "Live model duels and prompt arenas with frontier labs.", color: "from-primary to-accent" },
  { icon: Cpu, name: "Hackathon 48", desc: "48 hours. 100+ builders. Frontier bounties & global recognition.", color: "from-accent to-primary" },
  { icon: Bot, name: "Robotics Arena", desc: "Combat bots, swarm robotics & humanoid demos.", color: "from-primary to-destructive" },
  { icon: Gamepad2, name: "Gaming Championship", desc: "Esports finals across Valorant, BGMI & FC25.", color: "from-destructive to-accent" },
  { icon: Rocket, name: "Startup Pitching", desc: "Pitch to a global investor coalition for capital, mentorship and market access.", color: "from-primary to-accent" },
  { icon: Shield, name: "Cybersecurity CTF", desc: "Capture-the-flag tournaments with elite red teams.", color: "from-accent to-destructive" },
  { icon: Plane, name: "Drone Racing", desc: "FPV drone league inside the Delhi Tech Dome.", color: "from-primary to-accent" },
  { icon: Lightbulb, name: "Tech Quiz", desc: "National finals of the largest student tech quiz.", color: "from-accent to-primary" },
];

export function Events({ onOpen }: { onOpen: (i: number) => void }) {
  return (
    <section id="events" className="relative py-0 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader
          kicker="Featured Events"
          title="Eight Arenas. One Zenith."
          sub="Pick your battlefield. Each track is curated by global leaders and engineered for impact."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {EVENTS.map((e, i) => (
            <button
              key={e.name}
              onClick={() => onOpen(i)}
              className="hover-lift-6 group relative text-left glass border-glow rounded-2xl p-6 overflow-hidden"
            >
              <div className={`absolute -right-10 -top-10 size-32 rounded-full bg-gradient-to-br ${e.color} opacity-20 blur-2xl group-hover:opacity-40 transition`} />
              <div className={`relative inline-flex size-12 items-center justify-center rounded-xl bg-gradient-to-br ${e.color} glow-sm`}>
                <e.icon className="size-6 text-primary-foreground" />
              </div>
              <h3 className="mt-5 font-display text-2xl font-extrabold">{e.name}</h3>
              <p className="mt-2 text-sm text-foreground/80 font-medium leading-relaxed">{e.desc}</p>
              <div className="mt-5 inline-flex items-center text-xs font-bold text-primary">
                Explore <ChevronRight className="size-3 ml-1 group-hover:translate-x-1 transition" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}

export function GoldenBookVideo() {
  return (
    <section id="golden-book-awards" className="relative py-24 px-4 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <SectionHeader
          kicker="A Legacy in Motion"
          title="Golden Book Of Education"
          sub="Honoring 101 Great Educators Who Have Inspired the World — a global publication by the Education Council of GCCI."
        />
        <div
          className="relative group glass-strong border-glow rounded-3xl overflow-hidden"
        >
          <div className="absolute -inset-1 bg-gradient-to-r from-primary via-accent to-destructive opacity-30 blur-2xl group-hover:opacity-50 transition" />
          <div className="relative">
            <video
              src={goldenBookVideo}
              loop
              muted
              playsInline
              controls
              preload="none"
              poster={goldenBookPoster}
              className="w-full h-auto block aspect-video object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/95 via-background/30 to-transparent pointer-events-none" />
            <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-10 flex flex-col sm:flex-row sm:items-end sm:justify-between gap-5">
              <div className="max-w-2xl">
                <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-3 py-1 text-[10px] tracking-[0.3em] uppercase">
                  <BookMarked className="size-3 text-primary" /> Call for Nominations · Open Globally
                </div>
                <h3 className="mt-3 font-display text-2xl sm:text-4xl font-extrabold leading-tight">
                  The First <span className="text-gradient-primary">Golden Book Of Education</span>
                </h3>
                <p className="mt-2 text-sm sm:text-base text-foreground/85">
                  Featured inside the Principal's Conclave — submit your story, research or innovation and be formally recognized by the Hon'ble Education Minister.
                </p>
              </div>
              <Link
                to="/principals-conclave"
                hash="golden-book"
                className="shrink-0 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-bold text-primary-foreground glow-sm hover:scale-105 transition"
              >
                <Play className="size-4 fill-current" /> View Details
                <ChevronRight className="size-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function EventModal({ idx, onClose }: { idx: number | null; onClose: () => void }) {
  if (idx === null) return null;
  const e = EVENTS[idx];
  return (
    <motion.div
      initial={false}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-[100] grid place-items-center bg-background/80 backdrop-blur-md p-4"
    >
      <motion.div
        onClick={(ev) => ev.stopPropagation()}
        initial={{ scale: 0.95, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="glass-strong border-glow rounded-3xl max-w-lg w-full p-8 relative"
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute top-4 right-4 size-9 rounded-full glass border-glow grid place-items-center hover:bg-primary/10 transition"
        >
          <X className="size-4" />
        </button>
        <button
          onClick={onClose}
          aria-label="Back"
          className="absolute top-4 left-4 inline-flex items-center gap-1 px-3 py-1.5 rounded-full glass border-glow text-xs font-semibold hover:bg-primary/10 transition"
        >
          <ArrowLeft className="size-3.5" /> Back
        </button>
        <div className={`inline-flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br ${e.color} glow-sm`}>
          <e.icon className="size-7 text-primary-foreground" />
        </div>
        <h3 className="mt-8 font-display text-3xl font-extrabold text-gradient">{e.name}</h3>
        <p className="mt-3 text-foreground/80 font-medium">{e.desc}</p>
        <ul className="mt-6 space-y-2 text-sm">
          {["Open to: Students & Pros", "Format: On-site + Live Stream", "Duration: Three Days", "Venue: Indira Gandhi Pratishthan, Lucknow"].map(t => (
            <li key={t} className="flex items-center gap-2"><span className="size-1.5 rounded-full bg-primary" />{t}</li>
          ))}
        </ul>
        <button onClick={onClose} className="mt-7 w-full rounded-full bg-gradient-to-r from-primary to-accent py-3 text-sm font-semibold text-primary-foreground glow-sm">
          Apply for {e.name} →
        </button>
      </motion.div>
    </motion.div>
  );
}

/* ---------- Timeline ---------- */
const TIMELINE = [
  { day: "Day 01 · January 20", title: "Ignition", items: ["Opening keynote · Global Tech Council", "Principals Conclave roundtables", "Ideathon — Architect of Tomorrow begins", "Networking gala — Founders Lounge"] },
  { day: "Day 02 · January 21", title: "Acceleration", items: ["AI Battles main stage", "Employment Zone — recruitment drives", "Big Tech Talk Show podcast live", "Workshops · Robotics · Drones · AI", "Fragments of Genius Night — student performances"] },
  { day: "Day 03 · January 22", title: "Zenith", items: ["Tech Games grand finale", "Student Awards ceremony", "Startup Pitching finals", "Closing show & afterparty"] },
];

export function Timeline() {
  return (
    <section id="timeline" className="relative py-0 px-4 sm:px-6">
      <div className="mx-auto max-w-5xl">
        <SectionHeader kicker="Event Timeline" title="Three Days. One Ascent." />
        <div className="relative">
          <div className="absolute left-4 sm:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary/60 to-transparent" />
          <div className="space-y-12">
            {TIMELINE.map((t, i) => (
              <div
                key={t.day}
                className={`relative pl-12 sm:pl-0 sm:grid sm:grid-cols-2 sm:gap-12 ${i % 2 ? "sm:[&>*:first-child]:order-2" : ""}`}
              >
                <div className={`${i % 2 ? "sm:text-left" : "sm:text-right"}`}>
                  <div className="text-sm tracking-[0.3em] uppercase text-primary font-extrabold">{t.day}</div>
                  <h3 className="mt-2 font-display text-4xl font-extrabold">{t.title}</h3>
                </div>
                <div className="glass border-glow rounded-2xl p-6 mt-3 sm:mt-0">
                  <ul className="space-y-2 text-base font-bold">
                    {t.items.map(x => (
                      <li key={x} className="flex gap-2 items-start text-foreground">
                        <ChevronRight className="size-4 text-primary mt-0.5 shrink-0" />{x}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="absolute left-3 sm:left-1/2 top-1 -translate-x-1/2 size-3 rounded-full bg-primary glow-sm" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Speakers ---------- */
const SPEAKERS = [
  { name: "Dr. Anjali Mehra", role: "Chief Scientist, OpenMind AI", country: "🇮🇳 India" },
  { name: "Kenji Sato", role: "VP Robotics, NebulaWorks", country: "🇯🇵 Japan" },
  { name: "Lara Whitfield", role: "Partner, Apex Ventures", country: "🇺🇸 USA" },
  { name: "Hassan El-Sayed", role: "Founder, Cairo Cyber Labs", country: "🇪🇬 Egypt" },
  { name: "Sophia Andersen", role: "Head of EdTech, Nordic Foundation", country: "🇩🇰 Denmark" },
  { name: "Rohan Iyer", role: "CTO, AstraSpace", country: "🇮🇳 India" },
  { name: "Marta Kowalski", role: "Director, Warsaw AI Institute", country: "🇵🇱 Poland" },
  { name: "James Park", role: "Lead Engineer, Quantum Horizon", country: "🇰🇷 Korea" },
];

export function Speakers() {
  return (
    <section id="speakers" className="relative py-28 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader kicker="Voices of Zenith" title="20+ Global Minds. One Stage." sub="A handpicked lineup of operators, researchers and visionaries." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {SPEAKERS.map((s, i) => (
            <div
              key={s.name}
              className="hover-lift-6 group glass border-glow rounded-2xl p-5 relative overflow-hidden"
            >
              <div className="absolute -inset-px rounded-2xl bg-gradient-to-br from-primary/0 via-primary/0 to-primary/0 group-hover:from-primary/20 group-hover:to-accent/20 transition" />
              <div className="relative aspect-square rounded-xl overflow-hidden mb-4 bg-gradient-to-br from-secondary to-card">
                <div
                  className="w-full h-full"
                  style={{
                    background: `radial-gradient(circle at 50% 35%, oklch(0.45 0.15 ${20 + i * 8}), oklch(0.18 0.02 25) 70%)`,
                  }}
                />
                <div className="absolute inset-0 grid place-items-center font-display text-5xl font-bold text-foreground/90">
                  {s.name.split(" ").map(w => w[0]).slice(0, 2).join("")}
                </div>
                <div className="absolute top-2 right-2 glass text-[10px] px-2 py-1 rounded-full">{s.country}</div>
              </div>
              <h3 className="font-display font-semibold">{s.name}</h3>
              <p className="text-xs text-muted-foreground mt-1">{s.role}</p>
              <div className="mt-3 flex gap-2 text-muted-foreground">
                <Linkedin className="size-3.5 hover:text-primary transition" />
                <Twitter className="size-3.5 hover:text-primary transition" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Sponsors marquee ---------- */
const SPONSORS: { name: string; mark: string; tag: string; hue: string }[] = [
  { name: "Nebula AI",      mark: "◇", tag: "Frontier Models",        hue: "from-primary/40 to-accent/40" },
  { name: "ArcLight Cloud", mark: "◬", tag: "Edge Compute",           hue: "from-accent/40 to-destructive/40" },
  { name: "Quantum Labs",   mark: "◯", tag: "Research Partner",       hue: "from-primary/40 to-destructive/40" },
  { name: "Synapse",        mark: "✦", tag: "Developer Tools",        hue: "from-destructive/40 to-primary/40" },
  { name: "Hyperion",       mark: "❖", tag: "Robotics",               hue: "from-accent/40 to-primary/40" },
  { name: "Kairos Capital", mark: "△", tag: "Venture Partner",        hue: "from-primary/40 to-accent/40" },
  { name: "Astra Space",    mark: "✺", tag: "Aerospace",              hue: "from-accent/40 to-destructive/40" },
  { name: "Velocity Bank",  mark: "➤", tag: "Banking Partner",        hue: "from-primary/40 to-destructive/40" },
  { name: "Orbital Media",  mark: "◉", tag: "Broadcast Partner",      hue: "from-destructive/40 to-accent/40" },
  { name: "Nexus EdTech",   mark: "⬢", tag: "Education Partner",      hue: "from-primary/40 to-accent/40" },
  { name: "Helix Health",   mark: "∞", tag: "Healthtech",             hue: "from-accent/40 to-primary/40" },
  { name: "Prism Studios",  mark: "◮", tag: "Creative Partner",       hue: "from-destructive/40 to-primary/40" },
];
export function Sponsors() {
  const row = [...SPONSORS, ...SPONSORS];
  return (
    <section id="sponsors" className="relative py-0 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader kicker="Backed by the Best" title="Our Partners In Possibility." />
        <CarouselStrip>
          <div className="flex gap-5 animate-marquee w-max">
            {row.map((s, i) => (
              <div
                key={i} data-marquee-copy={i >= SPONSORS.length}
                className="glass-strong border-glow rounded-2xl px-5 py-4 flex items-center gap-4 opacity-90 hover:opacity-100 transition group min-w-[260px]"
              >
                <div className={`size-12 rounded-xl bg-gradient-to-br ${s.hue} grid place-items-center text-2xl text-foreground border border-white/20 group-hover:scale-110 transition shrink-0 shadow-sm`}>
                  {s.mark}
                </div>
                <div className="leading-tight">
                  <div className="font-display text-base font-extrabold tracking-wide">{s.name.toUpperCase()}</div>
                  <div className="text-[10px] tracking-[0.18em] uppercase text-muted-foreground font-bold">{s.tag}</div>
                </div>
              </div>
            ))}
          </div>
        </CarouselStrip>
        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            ["High Visibility", "Showcase your brand to 10,000+ targeted attendees across three cinematic days."],
            ["Global Exposure", "Engage attendees and exhibitors from 20+ countries — an international stage for your business."],
            ["Innovative Exhibits", "Stand alongside frontier AI, robotics, space and cybersecurity demos that command the floor."],
            ["1-2-1 Mentorship", "Direct sessions with global founders, investors and policy heads — relationships, not handshakes."],
          ].map(([t, b]) => (
            <div key={t} className="glass border-glow rounded-2xl p-6 relative overflow-hidden">
              <div className="text-xs tracking-[0.3em] uppercase text-primary font-bold">{t}</div>
              <p className="mt-3 text-sm text-foreground/85 leading-relaxed font-medium">{b}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <a href={withBase("/sponsors")} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm hover:opacity-95 transition">
            Why Exhibit or Sponsor →
          </a>
        </div>
      </div>
      <style>{`.mask-fade{mask-image:linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)}`}</style>
    </section>
  );
}

/* ---------- Gallery ---------- */
export function Gallery() {
const youthFest1 = [
  { src: youthFest1_01, t: "" },
  { src: youthFest1_02, t: "" },
  { src: youthFest1_03, t: "" },
  { src: youthFest1_04, t: "" },
  { src: youthFest1_05, t: "" },
  { src: youthFest1_06, t: "" },
  { src: youthFest1_07, t: "" },
  { src: youthFest1_08, t: "" },
  { src: youthFest1_09, t: "" },
  { src: youthFest1_10, t: "" },
  { src: youthFest1_11, t: "" },
  { src: youthFest1_12, t: "" },
  { src: youthFest1_13, t: "" },
  { src: youthFest1_14, t: "" },
  { src: youthFest1_15, t: "" },
];

const youthFest2 = [
  { src: youthFest2_01, t: "" },
  { src: youthFest2_02, t: "" },
  { src: youthFest2_03, t: "" },
  { src: youthFest2_04, t: "" },
  { src: youthFest2_05, t: "" },
  { src: youthFest2_07, t: "" },
  { src: youthFest2_08, t: "" },
  { src: youthFest2_09, t: "" },
  { src: youthFest2_10, t: "" },
  { src: youthFest2_11, t: "" },
  { src: youthFest2_12, t: "" },
];
  const ict = [
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-1.webp",  t: "ICT Week '24 · Opening Ceremony" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-3.webp",  t: "ICT Week '24 · Delegation Meet" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-4.webp",  t: "ICT Week '24 · Tech Showcase" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-6.webp",  t: "ICT Week '24 · Panel Session" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-7.webp",  t: "ICT Week '24 · Keynote Stage" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-9.webp",  t: "ICT Week '24 · Award Moment" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-11.webp", t: "ICT Week '24 · Hands-on Lab" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-13.webp", t: "ICT Week '24 · Startup Pitch" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-14.webp", t: "ICT Week '24 · Signing Ceremony" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-17.webp", t: "ICT Week '24 · Drone Demo" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-19.webp", t: "ICT Week '24 · Group Photo" },
    { src: "https://www.gcci.live/frontend/images/event/ict-week/gallery/ict-21.webp", t: "ICT Week '24 · VR Experience" },
  ];
  const glitch = [
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/1.jpeg",  t: "Glitch Tech Fest · Main Stage" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/3.jpeg",  t: "Glitch Tech Fest · Hackathon" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/5.jpeg",  t: "Glitch Tech Fest · Awards Night" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/6.jpeg",  t: "Glitch Tech Fest · Robotics Arena" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/8.jpeg",  t: "Glitch Tech Fest · Drone Racing" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/10.jpeg", t: "Glitch Tech Fest · Esports Finals" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/12.jpeg", t: "Glitch Tech Fest · Workshop" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/14.jpeg", t: "Glitch Tech Fest · Pitch Deck" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/17.jpeg", t: "Glitch Tech Fest · Stage Design" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/19.jpeg", t: "Glitch Tech Fest · Prototype Demo" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/24.jpeg", t: "Glitch Tech Fest · DJ Night" },
    { src: "https://www.gcci.live/frontend/images/gallery/glitchtechfest/26.jpeg", t: "Glitch Tech Fest · Trophy Moment" },
  ];
  const semicon = [
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/1_20250221_151219_0000.png",   t: "Semicon Vietnam · Inaugural Address" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/3_20250221_151219_0002.png",   t: "Semicon Vietnam · Industry Leaders Panel" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/5_20250221_151219_0004.png",   t: "Semicon Vietnam · Chip Showcase" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/7_20250221_151219_0006.png",   t: "Semicon Vietnam · Wafer Fab Walkthrough" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/9_20250221_151219_0008.png",   t: "Semicon Vietnam · Delegation Meet" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/11_20250221_151220_0010.png",  t: "Semicon Vietnam · Keynote Stage" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/13_20250221_151220_0012.png",  t: "Semicon Vietnam · Networking Lounge" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/15_20250221_151220_0014.png",  t: "Semicon Vietnam · MoU Signing" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/17_20250221_151220_0016.png",  t: "Semicon Vietnam · Innovation Pavilion" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/19_20250221_151220_0018.png",  t: "Semicon Vietnam · Startup Roundtable" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/22_20250221_151221_0021.png",  t: "Semicon Vietnam · Global Delegates" },
    { src: "https://gcci.live/frontend/images/event/semicon-vietnam/gallery/25_20250221_151221_0024.png",  t: "Semicon Vietnam · Closing Ceremony" },
  ];
  const Row = ({ items, reverse = false }: { items: { src: string; t: string }[]; reverse?: boolean }) => {
    const row = [...items, ...items];
    return (
      <CarouselStrip>
        <div
          className="flex gap-5 w-max animate-marquee"
          style={reverse ? { animationDirection: "reverse" } : undefined}
        >
          {row.map((it, i) => (
            <div
              key={i} data-marquee-copy={i >= items.length}
              className="relative w-[240px] sm:w-[280px] h-40 sm:h-48 rounded-2xl overflow-hidden border-glow glass shrink-0 group"
            >
              <img decoding="async"
                src={it.src}
                alt={it.t}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/70 via-foreground/10 to-transparent" />
              <div className="absolute bottom-3 left-4 right-4 font-display text-sm sm:text-base font-bold text-white drop-shadow">{it.t}</div>
            </div>
          ))}
        </div>
      </CarouselStrip>
    );
  };
  return (
<section className="relative py-10 px-4 sm:px-6">
  <div className="mx-auto max-w-7xl">
       <SectionHeader kicker="Past Event Glimpses" title="Moments That Shaped Our Legacy." sub="Frames from Youth Fest & Competitions, ICT Week Uzbekistan 2024, Glitch Tech Fest and Semicon Vietnam — a continuous reel of stages, wins and late-night build sessions." />


    <div className="space-y-6">
      <Row items={youthFest1} />
      <Row items={youthFest2} reverse />
      <Row items={ict} />
      <Row items={glitch} reverse />
      <Row items={semicon} />
    </div>
  </div>
</section>
  );
}

/* ---------- Registration ---------- */
const ROLES = ["Students", "University", "College", "Schools", "Coaching Centers", "EdTech Companies"] as const;
type Role = typeof ROLES[number];

const SUB_ROLES: Record<Role, string[]> = {
  Students: ["10th Grade", "12th Grade", "BA / BSc / BCom", "BBA", "BTech / BE", "CA / CS / CMA", "Diploma", "MBA / Masters", "PhD / Research"],
  University: ["Chancellor", "Vice Chancellor", "Pro Vice Chancellor", "Dean", "HOD", "Professor", "Assistant Professor", "Researcher"],
  College: ["Principal", "Vice Principal", "Head of Department", "Teacher / Faculty", "Lab Staff", "Administrative Staff", "Counsellor"],
  Schools: ["Principal", "Vice Principal", "Coordinator", "Teacher", "Activity Lead", "Administrative Staff"],
  "Coaching Centers": ["Founder / Director", "Centre Head", "Trainer / Faculty", "Counsellor", "Marketing Lead"],
  "EdTech Companies": ["Founder / CXO", "Product Manager", "Engineering / Tech", "Curriculum Lead", "Sales / Partnerships", "Marketing"],
};

const TRACKS_BY_ROLE: Record<Role, string[]> = {
  Students: ["Hackathon Participant", "Tech Games", "Workshops & Bootcamps", "Career & Internship Drives", "Startup Pitching"],
  University: ["Give a Keynote / Speech", "Attend the Roundtable", "Sign an MoU / Partnership", "Speaker on Panel", "Delegate Pass"],
  College: ["Give a Speech", "Attend the Principals Conclave Roundtable", "Speaker on Panel", "Bring a Student Cohort", "Delegate Pass"],
  Schools: ["Attend Principals Conclave", "Bring Student Cohort", "Speaker on Panel", "Delegate Pass"],
  "Coaching Centers": ["Exhibitor Booth", "Speaker on Panel", "Delegate Pass", "Sponsor"],
  "EdTech Companies": ["Exhibitor Booth", "Speaker on Panel", "Hiring Partner", "Sponsor", "Delegate Pass"],
};

const COUNTRIES = [
  "India","United States","United Kingdom","United Arab Emirates","Saudi Arabia","Qatar","Bahrain","Kuwait","Oman",
  "Singapore","Malaysia","Indonesia","Thailand","Vietnam","Philippines","Japan","South Korea","China","Hong Kong","Taiwan",
  "Australia","New Zealand","Canada","Mexico","Brazil","Argentina","Chile","Colombia",
  "Germany","France","Spain","Portugal","Italy","Netherlands","Belgium","Switzerland","Austria","Sweden","Norway","Denmark","Finland","Iceland","Ireland",
  "Poland","Czech Republic","Hungary","Romania","Greece","Turkey","Russia","Ukraine",
  "Israel","Egypt","Morocco","Tunisia","Algeria","Nigeria","Kenya","South Africa","Ghana","Ethiopia","Tanzania",
  "Nepal","Bhutan","Bangladesh","Sri Lanka","Pakistan","Afghanistan","Maldives",
  "Kazakhstan","Uzbekistan","Azerbaijan","Georgia","Armenia",
  "Other"
];

type FormData = {
  name: string;
  email: string;
  phone: string;
  role: Role | "";
  subRole: string;
  country: string;
  track: string;
};
type Errors = Partial<Record<keyof FormData, string>>;

const initial: FormData = { name: "", email: "", phone: "", role: "", subRole: "", country: "", track: "" };

function validateStep(step: number, data: FormData): Errors {
  const e: Errors = {};
  if (step === 0) {
    if (!data.name.trim() || data.name.trim().length < 2) e.name = "Please enter your full name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email.trim())) e.email = "Enter a valid email address.";
    if (!/^[+\d][\d\s().-]{6,}$/.test(data.phone.trim())) e.phone = "Enter a valid phone number.";
  } else if (step === 1) {
    if (!data.role) e.role = "Select your role.";
    if (!data.subRole) e.subRole = "Select your sub-role.";
    if (!data.country) e.country = "Select your country.";
    if (!data.track) e.track = "Pick a track to continue.";
  }
  return e;
}

export function Registration() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<FormData>(initial);
  const [errors, setErrors] = useState<Errors>({});
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [refId, setRefId] = useState("");
  const steps = ["Profile", "Interests", "Review"];

  const set = <K extends keyof FormData>(k: K, v: FormData[K]) => {
    setData(d => {
      const next = { ...d, [k]: v };
      if (k === "role") { next.subRole = ""; next.track = ""; }
      return next;
    });
    if (errors[k]) setErrors(e => ({ ...e, [k]: undefined }));
  };

  const next = () => {
    const e = validateStep(step, data);
    setErrors(e);
    if (Object.keys(e).length === 0) setStep(s => Math.min(2, s + 1));
  };

const submit = async () => {
  setSubmitting(true);

  const ref =
    "ZEN-" + Math.random().toString(36).slice(2, 8).toUpperCase();

  try {
    const fd = new FormData();

    fd.append(
      "_subject",
      `Zenith 2027 · New Registration · ${data.name} (${ref})`
    );

    fd.append("_template", "table");
    fd.append("_captcha", "false");

    fd.append("Reference", ref);
    fd.append("Name", data.name);
    fd.append("Email", data.email);
    fd.append("Phone", data.phone);
    fd.append("Role", data.role);
    fd.append("Sub-role", data.subRole);
    fd.append("Country", data.country);
    fd.append("Track", data.track);

    await fetch("https://formsubmit.co/ajax/info@gcci.live", {
      method: "POST",
      headers: {
        Accept: "application/json",
      },
      body: fd,
    });
  } catch {
    // Keep confirmation UI working even if email delivery fails.
  }

  setRefId(ref);
  setSubmitting(false);
  setDone(true);
};

  const reset = () => {
    setData(initial); setErrors({}); setStep(0); setDone(false); setRefId("");
  };

  return (
    <section id="register" className="relative py-0 px-4 sm:px-6">
      <div className="mx-auto max-w-3xl">
        <SectionHeader kicker="Secure Your Pass" title="Register For Zenith 2027." sub="Limited delegate seats. Free for verified students." />
        <div className="glass-strong border-glow rounded-3xl p-6 sm:p-10 relative overflow-hidden">
          {!done && (
            <div className="flex items-center gap-2 mb-8">
              {steps.map((s, i) => (
                <div key={s} className="flex items-center flex-1">
                  <div className={`size-8 rounded-full grid place-items-center text-xs font-semibold transition ${
                    i <= step ? "bg-gradient-to-br from-primary to-accent text-primary-foreground glow-sm" : "bg-secondary text-muted-foreground"
                  }`}>{i < step ? <CheckCircle2 className="size-4" /> : i + 1}</div>
                  <div className="ml-2 text-xs text-muted-foreground hidden sm:block">{s}</div>
                  {i < steps.length - 1 && <div className={`flex-1 h-px mx-3 ${i < step ? "bg-primary" : "bg-border"}`} />}
                </div>
              ))}
            </div>
          )}

          <AnimatePresence mode="wait">
            {done ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="text-center py-8"
              >
                <motion.div
                  initial={{ scale: 0, rotate: -90 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 200, damping: 14 }}
                  className="size-20 rounded-full bg-gradient-to-br from-primary to-accent mx-auto grid place-items-center glow"
                >
                  <CheckCircle2 className="size-10 text-primary-foreground" />
                </motion.div>
                <h3 className="mt-6 font-display text-3xl font-bold">You're in, {data.name.split(" ")[0]}.</h3>
                <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
                  Your seat at Zenith 2027 is locked. A confirmation has been sent to <span className="text-foreground">{data.email}</span>.
                </p>
                <div className="mt-6 inline-flex items-center gap-3 rounded-full glass px-5 py-2.5">
                  <Sparkles className="size-4 text-primary" />
                  <span className="text-xs tracking-[0.2em] uppercase text-muted-foreground">Reference</span>
                  <span className="font-mono text-sm text-foreground">{refId}</span>
                </div>
                <div className="mt-8 grid sm:grid-cols-3 gap-3 text-left max-w-xl mx-auto">
                  <ReviewCard label="Track" value={data.track} />
                  <ReviewCard label="Role" value={data.role} />
                  <ReviewCard label="Country" value={data.country} />
                </div>
                <button
                  onClick={reset}
                  className="mt-8 px-6 py-2.5 rounded-full text-sm glass border-glow hover:bg-primary/10 transition"
                >Register another delegate</button>
              </motion.div>
            ) : (
              <motion.div
                key={step}
                initial={false}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
              >
                {step === 0 && (
                  <div className="space-y-4">
                    <Field label="Full Name" placeholder="Aarav Sharma" value={data.name} onChange={e => set("name", e.target.value)} error={errors.name} />
                    <Field label="Email" placeholder="you@domain.com" type="email" value={data.email} onChange={e => set("email", e.target.value)} error={errors.email} />
                    <Field label="Phone" placeholder="+91 98765 43210" value={data.phone} onChange={e => set("phone", e.target.value)} error={errors.phone} />
                  </div>
                )}
                {step === 1 && (
                  <div className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mb-2">Role</div>
                        <select
                          value={data.role}
                          onChange={e => set("role", e.target.value as Role)}
                          className={`w-full rounded-xl bg-input/60 border px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition ${errors.role ? "border-destructive" : "border-border"}`}
                        >
                          <option value="">Select role…</option>
                          {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                        {errors.role && <ErrorLine msg={errors.role} />}
                      </div>
                      <div>
                        <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mb-2">Job Role / Sub-role</div>
                        <select
                          value={data.subRole}
                          disabled={!data.role}
                          onChange={e => set("subRole", e.target.value)}
                          className={`w-full rounded-xl bg-input/60 border px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition disabled:opacity-50 ${errors.subRole ? "border-destructive" : "border-border"}`}
                        >
                          <option value="">{data.role ? "Select sub-role…" : "Pick a role first"}</option>
                          {data.role && SUB_ROLES[data.role as Role].map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        {errors.subRole && <ErrorLine msg={errors.subRole} />}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mb-2">Country</div>
                      <select
                        value={data.country}
                        onChange={e => set("country", e.target.value)}
                        className={`w-full rounded-xl bg-input/60 border px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition ${errors.country ? "border-destructive" : "border-border"}`}
                      >
                        <option value="">Select your country…</option>
                        {COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                      {errors.country && <ErrorLine msg={errors.country} />}
                    </div>
                    <div>
                      <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mb-3">Pick your track</div>
                      {!data.role && (
                        <div className="glass border-glow rounded-xl p-4 text-sm text-muted-foreground">
                          Tracks unlock once you select a role above.
                        </div>
                      )}
                      <div className="grid sm:grid-cols-2 gap-3">
                        {data.role && TRACKS_BY_ROLE[data.role as Role].map(t => {
                          const active = data.track === t;
                          return (
                            <label key={t} className={`glass rounded-xl p-4 cursor-pointer transition border ${active ? "border-primary glow-sm" : "border-transparent hover:border-primary/60"}`}>
                              <input
                                type="radio"
                                name="track"
                                className="accent-primary mr-2"
                                checked={active}
                                onChange={() => set("track", t)}
                              />
                              <span className="text-sm">{t}</span>
                            </label>
                          );
                        })}
                      </div>
                      {errors.track && <ErrorLine msg={errors.track} />}
                    </div>
                  </div>
                )}
                {step === 2 && (
                  <div>
                    <div className="text-center mb-6">
                      <h3 className="font-display text-2xl font-bold">Review your details</h3>
                      <p className="mt-1 text-sm text-muted-foreground">Confirm everything looks right before locking your seat.</p>
                    </div>
                    <div className="grid sm:grid-cols-2 gap-3">
                      <ReviewCard label="Name" value={data.name} />
                      <ReviewCard label="Email" value={data.email} />
                      <ReviewCard label="Phone" value={data.phone} />
                      <ReviewCard label="Role" value={data.role} />
                      <ReviewCard label="Sub-role" value={data.subRole} />
                      <ReviewCard label="Country" value={data.country} />
                      <ReviewCard label="Track" value={data.track} />
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {!done && (
            <div className="mt-8 flex justify-between gap-3">
              <button
                onClick={() => setStep(Math.max(0, step - 1))}
                disabled={step === 0 || submitting}
                className="px-5 py-2.5 rounded-full text-sm glass border-glow disabled:opacity-40"
              >Back</button>
              <button
                onClick={step === 2 ? submit : next}
                disabled={submitting}
                className="px-6 py-2.5 rounded-full text-sm font-semibold bg-gradient-to-r from-primary to-accent text-primary-foreground glow-sm disabled:opacity-70 inline-flex items-center gap-2"
              >
                {submitting && <Loader2 className="size-4 animate-spin" />}
                {step === 2 ? (submitting ? "Confirming…" : "Confirm Registration") : "Continue"}
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function ReviewCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-xl p-4">
      <div className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground">{label}</div>
      <div className="mt-1 text-sm text-foreground truncate">{value || "—"}</div>
    </div>
  );
}

function ErrorLine({ msg }: { msg: string }) {
  return (
    <div className="mt-2 flex items-center gap-1.5 text-xs text-destructive">
      <AlertCircle className="size-3.5" /> {msg}
    </div>
  );
}

function Field({ label, error, ...p }: { label: string; error?: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <div className="text-[11px] tracking-[0.2em] uppercase text-muted-foreground mb-2">{label}</div>
      <input
        {...p}
        className={`w-full rounded-xl bg-input/60 border px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition ${error ? "border-destructive" : "border-border"}`}
      />
      {error && <ErrorLine msg={error} />}
    </label>
  );
}

/* ---------- FAQ ---------- */
const FAQS = [
  ["When and where is Zenith 2027?", "20th–22nd January 2027 at Indira Gandhi Pratishthan, Lucknow, India."],
  ["Who can attend?", "Students (13+), founders, engineers, educators and policy makers. Verified students attend free with valid ID."],
  ["Are there scholarships and travel grants?", "Sponsors can offer sponsored seats for underrepresented students across India & Partner Countries."],
  ["Can my company sponsor or exhibit?", "Absolutely. Tiers start at ₹1.5L (Silver) up to ₹10L (Title). Reach out via the partnerships email below."],
  ["Will sessions be live-streamed?", "All main-stage keynotes and finals will be streamed worldwide in 4K with on-demand replays."],
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="relative py-28 px-4 sm:px-6">
      <div className="mx-auto max-w-3xl">
        <SectionHeader kicker="FAQ" title="Everything You Wanted To Know." />
        <div className="space-y-3">
          {FAQS.map(([q, a], i) => {
            const isOpen = open === i;
            return (
              <div key={q} className="glass border-glow rounded-2xl overflow-hidden">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 p-5 text-left"
                >
                  <span className="font-medium">{q}</span>
                  {isOpen ? <Minus className="size-4 text-primary shrink-0" /> : <Plus className="size-4 text-primary shrink-0" />}
                </button>
                <motion.div
                  initial={false}
                  animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">{a}</p>
                </motion.div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- Footer ---------- */
/* ---------- Tech Games ---------- */
const TECH_GAMES = [
  { icon: Joystick, name: "Code Royale", desc: "Battle-royale style live coding arena — last keyboard standing." },
  { icon: Bot, name: "Bot Sumo", desc: "Engineer your own sumo bot. Push the opponent off the ring." },
  { icon: Brain, name: "AI Duel", desc: "Two prompt-wizards. One model. Best response wins the crowd." },
  { icon: Plane, name: "Drone Gauntlet", desc: "FPV obstacle racing through a neon-lit indoor circuit." },
  { icon: Shield, name: "Cyber Heist", desc: "Capture-the-flag with a heist twist. 4-player teams." },
  { icon: Gamepad2, name: "Pixel Wars", desc: "Build a working retro game in 90 minutes. Live judging." },
];

export function TechGames() {
  return (
    <section id="tech-games" className="relative py-0 px-4 sm:px-6">
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="relative mx-auto max-w-7xl">
        <SectionHeader
          kicker="Tech Games"
          title="Today's Students Are The Architects Of Tomorrow's World."
          sub="Six original tech games, designed to turn curiosity into muscle memory. Built for the next generation of makers."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {TECH_GAMES.map((g, i) => (
            <div
              key={g.name}
              className="hover-lift-6 group glass border-glow rounded-2xl p-6 relative overflow-hidden"
            >
              <div className="absolute -right-10 -top-10 size-32 rounded-full bg-gradient-to-br from-primary to-accent opacity-20 blur-2xl group-hover:opacity-40 transition" />
              <div className="relative inline-flex size-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent glow-sm">
                <g.icon className="size-6 text-primary-foreground" />
              </div>
              <h3 className="mt-5 font-display text-2xl font-extrabold">{g.name}</h3>
              <p className="mt-2 text-sm text-foreground/80 font-medium leading-relaxed">{g.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Student Awards ---------- */
/* ---------- AI Week & Cyber Week posters ---------- */
export function TechWeeks() {
  const weeks = [
    {
      href: "/podcast-room#ai-week",
      src: aiWeek,
      title: "AI Week",
      tag: "Connecting Emerging Leaders",
      blurb: "Conferences, seminars, red-team CTFs and roundtables with the AI ecosystem.",
    },
    {
      href: "/podcast-room#cyber-week",
      src: cyberWeek,
      title: "Cyber Week",
      tag: "Global Security Conversation",
      blurb: "Conferences, seminars, red-team CTFs and roundtables with the cyber ecosystem.",
    },
  ];
  return (
    <section id="tech-weeks" className="relative py-20 px-4 sm:px-6">
      <div className="mx-auto max-w-4xl">
        <SectionHeader
          kicker="Programme Weeks"
          title="AI Week & Cyber Week"
          sub="Tap a poster to open the full programme inside the Podcast Room."
        />
        <div className="grid sm:grid-cols-2 gap-5">
          {weeks.map((w, i) => (
            <a
              key={w.title}
              href={withBase(w.href)}
              className="hover-lift-6 group relative block rounded-3xl overflow-hidden border-glow glass-strong"
              aria-label={`${w.title} — open programme in the Podcast Room`}
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img decoding="async"
                  src={w.src}
                  alt={`${w.title} programme poster`}
                  width={1024}
                  height={683}
                  loading="lazy"
                  className="absolute inset-0 size-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/10 to-transparent" />
                <div className="absolute bottom-4 left-5 right-5">
                  <div className="text-[10px] tracking-[0.3em] uppercase text-primary font-bold">{w.tag}</div>
                  <p className="mt-1 text-sm font-semibold text-foreground drop-shadow">{w.blurb}</p>
                  <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-4 py-2 text-xs font-bold text-primary-foreground glow-sm">
                    Open in Podcast Room <ChevronRight className="size-3.5" />
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

const STUDENT_AWARDS = [
  { title: "Young Innovator", desc: "Most original student-built project demonstrated at Zenith." },
  { title: "Code Champion", desc: "Top performer across Code Royale + Hackathon tracks." },
  { title: "Future Founder", desc: "Best student-led startup pitch under 21." },
  { title: "AI Visionary", desc: "Outstanding student work in applied AI / ML research." },
  { title: "Robotics Maker", desc: "Best engineered bot across the Bot Sumo and Robotics Arena." },
  { title: "Impact Hacker", desc: "Project with the strongest social or sustainability impact." },
];

export function StudentAwards() {
  return (
    <section id="student-awards" className="relative py-28 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader
          kicker="Student Awards"
          title="Honouring The Architects Of Tomorrow."
          sub="Six dedicated student awards across innovation, code, design and impact. Nominations open Nov 2026."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {STUDENT_AWARDS.map((a, i) => (
            <div
              key={a.title}
              className="glass-strong border-glow rounded-2xl p-6 relative overflow-hidden"
            >
              <Trophy className="size-7 text-primary" />
              <h3 className="mt-4 font-display text-xl font-semibold text-gradient">{a.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{a.desc}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 flex justify-center">
          <a href={withBase("/awards")} className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm">
            See all awards →
          </a>
        </div>
      </div>
    </section>
  );
}

/* ---------- Media Coverage & Media Bytes ---------- */
const MEDIA = [
  { name: "Aaj Tak",         src: "https://gcci.live/frontend/images/event/3rd-icc/channels/aaj-tak.png" },
  { name: "ABP News",        src: "https://gcci.live/frontend/images/event/3rd-icc/channels/abp-news.avif" },
  { name: "ANI",             src: "https://gcci.live/frontend/images/event/3rd-icc/channels/ani-news.svg" },
  { name: "CNN News18",      src: "https://gcci.live/frontend/images/event/3rd-icc/channels/cnn-news18.avif" },
  { name: "DD News",         src: "https://gcci.live/frontend/images/event/3rd-icc/channels/dd-news.jpg" },
  { name: "Hindustan Times", src: "https://gcci.live/frontend/images/event/3rd-icc/channels/hindustan-times.png" },
  { name: "IBC 24",          src: "https://gcci.live/frontend/images/event/3rd-icc/channels/ibc-24.jpeg" },
  { name: "India Today",     src: "https://gcci.live/frontend/images/event/3rd-icc/channels/india-today.png" },
  { name: "NDTV",            src: "https://gcci.live/frontend/images/event/3rd-icc/channels/ndtv.png" },
  { name: "News 18",         src: "https://gcci.live/frontend/images/event/3rd-icc/channels/news-18.png" },
  { name: "PTI",             src: "https://gcci.live/frontend/images/event/3rd-icc/channels/pti-news.jpg" },
  { name: "Republic",        src: "https://gcci.live/frontend/images/event/3rd-icc/channels/republic-news.png" },
  { name: "The Hindu",       src: "https://gcci.live/frontend/images/event/3rd-icc/channels/the-hindu.png" },
  { name: "Zee News",        src: "https://gcci.live/frontend/images/event/3rd-icc/channels/zee-news.png" },
];
export function MediaCoverage() {
  const row = [...MEDIA, ...MEDIA];
  return (
    <section id="media" className="relative py-0 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader kicker="Media Coverage & Media Bytes" title="Covered By India's Biggest Newsrooms." sub="National & international correspondents broadcasting Zenith stories — print, broadcast, digital." />
        <CarouselStrip>
          <div className="flex gap-5 animate-marquee w-max">
            {row.map((m, i) => (
              <div key={i} data-marquee-copy={i >= MEDIA.length} className="glass-strong border-glow rounded-2xl px-6 py-5 min-w-[200px] h-24 flex items-center justify-center bg-white shrink-0">
                <img decoding="async" src={m.src} alt={m.name} loading="lazy" className="max-h-14 max-w-[150px] object-contain" />
              </div>
            ))}
          </div>
        </CarouselStrip>
        <style>{`.mask-fade{mask-image:linear-gradient(90deg,transparent,#000 10%,#000 90%,transparent)}`}</style>
      </div>
    </section>
  );
}

/* ---------- Hiring Companies + Government Partners (dual marquee) ---------- */
const HIRING_COMPANIES = [
  { name: "TCS",           domain: "tcs.com" },
  { name: "Infosys",       domain: "infosys.com" },
  { name: "Wipro",         domain: "wipro.com" },
  { name: "Accenture",     domain: "accenture.com" },
  { name: "Cognizant",     domain: "cognizant.com" },
  { name: "Capgemini",     domain: "capgemini.com" },
  { name: "HCLTech",       domain: "hcltech.com" },
  { name: "Tech Mahindra", domain: "techmahindra.com" },
  { name: "Amazon",        domain: "amazon.com" },
  { name: "Microsoft",     domain: "microsoft.com" },
  { name: "Google",        domain: "google.com" },
  { name: "Deloitte",      domain: "deloitte.com" },
  { name: "EY",            domain: "ey.com" },
  { name: "IBM",           domain: "ibm.com" },
  { name: "Oracle",        domain: "oracle.com" },
  { name: "Adobe",         domain: "adobe.com" },
];
const GOV_LOGOS = [gov1, gov2, gov3, gov4, gov5, gov6, gov7];

export function HiringPartners() {
  const hires = [...HIRING_COMPANIES, ...HIRING_COMPANIES];
  const govs = [...GOV_LOGOS, ...GOV_LOGOS];
  return (
    <section id="hiring-partners" className="relative py-28 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <SectionHeader
          kicker="Hiring & Government Partners"
          title="World Companies. Indian Government. One Stage."
          sub="The MNCs hiring the most freshers in India — alongside the government departments backing Zenith 2027."
        />

        {/* Hiring companies — left to right */}
        <div className="kicker text-primary mb-5">Top Fresher Recruiters</div>
        <CarouselStrip>
          <div className="flex gap-4 w-max animate-marquee" style={{ animationDirection: "reverse" }}>
            {hires.map((c, i) => (
              <div key={i} data-marquee-copy={i >= HIRING_COMPANIES.length} className="relative glass-strong rounded-2xl px-5 py-4 flex items-center gap-3 min-w-[240px] shrink-0 ring-1 ring-primary/40 hover:ring-2 hover:ring-primary/80 transition shadow-[0_0_20px_-8px_rgba(255,90,40,0.45)]">
                <span className="absolute -top-2 -right-2 rounded-full bg-gradient-to-r from-primary to-accent text-primary-foreground text-[8px] tracking-[0.22em] uppercase font-extrabold px-2 py-0.5">Top</span>
                <div className="size-12 rounded-xl bg-white grid place-items-center shrink-0 border border-border/60 overflow-hidden">
                  <img decoding="async"
                    src={`https://logo.clearbit.com/${c.domain}`}
                    alt={`${c.name} logo`}
                    loading="lazy"
                    className="max-h-8 max-w-9 object-contain"
                    onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
                  />
                </div>
                <div className="font-hero text-[15px] font-bold tracking-wide">{c.name}</div>
              </div>
            ))}
          </div>
        </CarouselStrip>

        {/* Government partners — right to left */}
        <div className="kicker text-primary mt-12 mb-5">Government & Institutional Partners</div>
        <CarouselStrip>
          <div className="flex gap-5 w-max animate-marquee">
            {govs.map((g, i) => (
              <div key={i} data-marquee-copy={i >= GOV_LOGOS.length} className="glass-strong border-glow rounded-2xl px-5 py-4 h-28 min-w-[200px] flex items-center justify-center bg-white shrink-0">
                <img decoding="async" src={g} alt="Government Partner" loading="lazy" className="max-h-20 max-w-[160px] object-contain" />
              </div>
            ))}
          </div>
        </CarouselStrip>
      </div>
    </section>
  );
}
