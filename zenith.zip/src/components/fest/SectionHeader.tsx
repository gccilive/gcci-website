export function SectionHeader({
  kicker,
  title,
  sub,
}: {
  kicker: string;
  title: string;
  sub?: string;
}) {
  return (
    <div className="mx-auto max-w-3xl text-center mb-14 section-title">
      <div className="kicker text-primary justify-center">{kicker}</div>
      <h2 className="mt-4 headline-lg text-gradient">{title}</h2>
      {sub && <p className="mt-5 lead">{sub}</p>}
    </div>
  );
}
