import { useEffect, useRef, type ReactNode } from "react";

/** CSS moves only visible mobile carousels; no animation-frame or React loops. */
export function CarouselStrip({ children }: { children: ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = ref.current;
    const track = container?.firstElementChild as HTMLElement | null;
    if (!container || !track || typeof IntersectionObserver === "undefined") return;

    const mobile = window.matchMedia("(max-width: 767px), (pointer: coarse), (hover: none)");
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let visible = false;
    const measure = () => {
      const first = track.firstElementChild as HTMLElement | null;
      const copy = track.querySelector<HTMLElement>('[data-marquee-copy="true"]');
      if (!first || !copy) return;
      const distance = copy.offsetLeft - first.offsetLeft;
      track.style.setProperty("--carousel-shift", `${-distance}px`);
      track.style.setProperty("--carousel-duration", `${Math.max(40, distance / 20)}s`);
    };
    const update = () => {
      const enabled = mobile.matches && !reducedMotion.matches;
      container.dataset.mobileCarousel = String(enabled);
      measure();
      container.dataset.moving = String(enabled && visible && !document.hidden);
    };
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      update();
    });
    observer.observe(container);
    const resize = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(measure);
    resize?.observe(track);
    mobile.addEventListener("change", update);
    reducedMotion.addEventListener("change", update);
    document.addEventListener("visibilitychange", update);
    window.addEventListener("resize", measure, { passive: true });
    update();
    return () => {
      observer.disconnect();
      resize?.disconnect();
      mobile.removeEventListener("change", update);
      reducedMotion.removeEventListener("change", update);
      document.removeEventListener("visibilitychange", update);
      window.removeEventListener("resize", measure);
    };
  }, []);

  return (
    <div ref={ref} className="relative overflow-hidden mask-fade mobile-scroll-strip">
      {children}
    </div>
  );
}
