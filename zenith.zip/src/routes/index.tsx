import { Footer } from "@/components/fest/Footer";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AnimatePresence, LazyMotion, domAnimation } from "framer-motion";
import { Nav } from "@/components/fest/Nav";
import { SocialSidebar } from "@/components/fest/SocialSidebar";
import { Hero } from "@/components/fest/Hero";
import {
  About,
  Events,
  EventModal,
  Timeline,
  Sponsors,
  Gallery,
  Registration,
  FAQ,
  TechGames,
  StudentAwards,
  Nights,
  TechWeeks,
  MediaCoverage,
  HiringPartners,
  GoldenBookVideo,
  EmbassiesOfInnovation,
  ExtraordinaryYouthEngagement,
} from "@/components/fest/Sections";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Global Youth Tech & Innovation Summit" },
      {
        name: "description",
        content:
          "20th, 21st, 22nd January 2027 · Indira Gandhi Pratishthan, Lucknow. 20+ speakers, 10,000 attendees, 200+ exhibitors. Today's students are architects of tomorrow's world.",
      },
      {
        property: "og:title",
        content: "Global Youth Tech & Innovation Summit",
      },
      {
        property: "og:description",
        content:
          "20th, 21st, 22nd January 2027 · Indira Gandhi Pratishthan, Lucknow. Today's students are architects of tomorrow's world.",
      },
    ],
  }),
});

function Index() {
  const [modal, setModal] = useState<number | null>(null);
  return (
    <LazyMotion features={domAnimation} strict>
      <div className="relative min-h-screen">
        <Nav />
        <SocialSidebar />
        <main>
          <Hero />

          <About />
          <Gallery />
          <EmbassiesOfInnovation />
          <Nights />
          <ExtraordinaryYouthEngagement />
          <Events onOpen={setModal} />
          <GoldenBookVideo />
          <TechGames />
          <TechWeeks />
          <Timeline />
          <StudentAwards />
          <Sponsors />
          <HiringPartners />
          <MediaCoverage />

          <Registration />
          <FAQ />
        </main>
        <Footer />
        <AnimatePresence>
          {modal !== null && (
            <EventModal idx={modal} onClose={() => setModal(null)} />
          )}
        </AnimatePresence>
      </div>
    </LazyMotion>
  );
}
