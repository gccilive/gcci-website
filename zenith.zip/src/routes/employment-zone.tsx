import { createFileRoute, Link } from "@tanstack/react-router";
import { Briefcase, GraduationCap, Compass, Building2, Globe, Sparkles, Rocket, Cpu, Camera, Trophy, FileCheck2, ScanLine, Star } from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { SocialSidebar } from "@/components/fest/SocialSidebar";
import { Footer } from "@/components/fest/Footer";

export const Route = createFileRoute("/employment-zone")({
  component: Page,
  head: () => ({
    meta: [
      { title: "Employment Zone · Zenith 2027" },
      { name: "description", content: "The Employment Zone at Zenith 2027 — internships, placements, career guidance, recruitment and global opportunities." },
    ],
  }),
});

const TRACKS = [
  { I: GraduationCap, t: "Upskilling & Certification Corner", d: "Stalls from professional training programs, bootcamps and education platforms showcasing certifications for emerging technologies." },
  { I: Rocket, t: "Live Demo Alley", d: "Companies and early-stage startups showcase products live — see real culture, real tooling, real day-to-day operations." },
  { I: Cpu, t: "AI-Powered Career Matching", d: "Interactive touchscreen kiosks match candidates with relevant roles and tech companies in minutes." },
  { I: Camera, t: "Photo Booth", d: "Professional headshot zone for career profiles, LinkedIn and recruiter outreach." },
  { I: Trophy, t: "Gamified Leaderboard", d: "Mini-challenges and a hidden QR-code hunt — top scorers win early interview access and partner swag." },
  { I: Star, t: "Golden Ticket Mock Interviews", d: "Technical & HR rounds with industry volunteers. Top performers get a Golden Ticket — guaranteed interview at an employer booth." },
  { I: FileCheck2, t: "Service-to-Product Resume Overhauls", d: "Reformat service-background projects for product giants like Adobe. Includes ATS optimisation for MNC screeners." },
  { I: ScanLine, t: "ATS & Profile Optimization Clinics", d: "High-footfall audits of resumes and GitHub repos. Branded partner QR codes route vetted candidates into open pipelines." },
  { I: Compass, t: "Career Guidance", d: "1:1 sessions with industry mentors. Portfolio audits, story coaching, mock interviews." },
  { I: Building2, t: "Placement Drives", d: "On-spot offers from 80+ Indian and global employers across tech, product and consulting." },
];

// Day 1 — Sourcing, Screening & Skill Validation (Nov 26)
const AGENDA_D1 = [
  { time: "08:30 – 10:00", title: "Tech Check & Booth Handover", d: "100 Mbps leased line checks, Micro-Hackathon Lab terminals, badges handed to early recruiters." },
  { time: "10:00 – 11:30", title: "Sourcing Track Kick-off & ATS Clinic Live", d: "Doors open for final-year students. ATS Resume Optimization Clinic helps freshers format CVs into partner pipelines." },
  { time: "11:30 – 13:00", title: "Hackathon Wave 1 & Boardroom Arena 1", d: "Micro-Lab: Frontend & UI/UX Sprint (60 min). Top performers win a Golden Ticket. System Design Arena: Panel on Scaling Enterprise Systems." },
  { time: "13:00 – 14:00", title: "Pre-Vetted Interview Cabin Openings", d: "Private cabins open for round-1 technical assessments for early registrants and Hackathon Wave 1 leaders." },
  { time: "14:00 – 15:00", title: "Staggered Lunch Break", d: "Half the workforce rotates while the other half keeps interview lines moving — no bottlenecks." },
  { time: "15:00 – 16:30", title: "Hackathon Wave 2 & Boardroom Arena 2", d: "Micro-Lab: Backend & API Integrations (Node.js / Python). System Design: Building Fraud-Detection Pipelines for massive scale." },
  { time: "16:30 – 18:00", title: "Open Bug Bounty & Day 1 Wrap-up", d: "45-minute rapid debugging sprint open to all. Recruiters push shortlists to the central server for Day 2 selections." },
];

// Day 2 — Fast-Track Selection & Spot Job Offers (Nov 27)
const AGENDA_D2 = [
  { time: "08:30 – 09:30", title: "Day 2 Setup & Shortlist Rollouts", d: "Automated WhatsApp / SMS alerts to Day 1 clearing candidates inviting them for final rounds." },
  { time: "09:30 – 11:30", title: "Experienced Cohort Inflow & Rapid Rounds", d: "Mid-to-senior professionals (1–5 yrs) prioritized. Private interview cabins open for technical grilling." },
  { time: "11:30 – 13:00", title: "Grand Product Sprint & Reverse Pitching", d: "90-minute Full-Stack build sprint for advanced devs. Elite developers reverse-pitch GitHub portfolios to local founders & CTOs." },
  { time: "13:00 – 14:00", title: "Startup Mini-Challenges", d: "30-minute problem statements deployed on the lab floor to catch quick-thinking talent." },
  { time: "14:00 – 15:00", title: "Staggered Lunch Break", d: "Operations shift change. Refreshments delivered to corporate cabins to keep recruiters comfortable through peak evaluation." },
  { time: "15:00 – 17:00", title: "Closing Interview Surge & HR Lock-ins", d: "Final rounds, salary negotiations, lock-down of selections. Lab closes for candidate database processing." },
  { time: "17:00 – 18:00", title: "Spot Offers & Corporate Mixer", d: "Trophies for hackathon winners. Partners roll out official Spot Offer Letters. Event teardown begins." },
];

// Day 3 — Offer Letter Distribution & Onboarding (Nov 28)
const AGENDA_D3 = [
  { time: "09:00 – 10:30", title: "Welcome & Final Verifications", d: "Selected candidates check in. Document verification, ID and background confirmations completed at speed-desks." },
  { time: "10:30 – 12:00", title: "Career Briefings by Partner Companies", d: "Top recruiters address their incoming cohorts — role, team, growth path and first-90-day expectations." },
  { time: "12:00 – 13:30", title: "Offer Letter Distribution Ceremony", d: "The flagship moment — official offer letters handed over on the Main Stage by partner CHROs and the Zenith leadership. Cameras rolling, families invited." },
  { time: "13:30 – 14:30", title: "Celebration Lunch & Family Hour", d: "Selected candidates and their families gather for a celebration lunch with recruiters." },
  { time: "14:30 – 16:00", title: "Onboarding & Joining Formalities Desk", d: "HR desks of partner companies complete digital onboarding — joining dates, location preferences, document uploads." },
  { time: "16:00 – 17:30", title: "International Offers & Visa Briefings", d: "Cross-border offer holders meet relocation partners. Visa paperwork kick-off for UAE, Singapore, Germany, UK and Canada." },
  { time: "17:30 – 18:30", title: "Zenith Closing & Group Photograph", d: "Class of Zenith 2027 photograph on the Main Stage. The journey from candidate to colleague — sealed." },
];

function Page() {
  return (
    <div className="relative min-h-screen bg-hero">
      <Nav />
      <SocialSidebar />
      <main className="pt-32 pb-24 px-4 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase">
              <Briefcase className="size-3 text-primary" /> January 20 · 21 · 22 · Three-Day Programme
            </div>
            {/* <div className="mt-4 inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-primary/15 via-accent/15 to-destructive/15 border border-primary/40 px-5 py-2">
              <span className="font-mono text-[10px] tracking-[0.32em] uppercase text-primary font-extrabold">Organising Partner</span>
              <span className="size-1 rounded-full bg-primary" />
              <span className="font-display text-base sm:text-lg font-extrabold text-gradient-primary">JSkillz</span>
            </div> */}
            <h1 className="mt-6 font-display text-5xl sm:text-7xl font-bold leading-[1.05]">
              Employment <span className="text-gradient-primary">Zone</span>
            </h1>
            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
              From your first internship to your first international offer — all in one hall. Three career-defining days
              (<span className="text-foreground font-bold">January 20 · 21 · 22, 2027</span>), <span className="text-foreground font-bold">200+ attendees</span>,
              <span className="text-foreground font-bold"> 200+ exhibitors</span> and a closing-day <span className="text-foreground font-bold">Offer Letter Distribution Ceremony</span> on the Main Stage.
            </p>
          </div>

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {TRACKS.map(({ I, t, d }, i) => (
              <div key={t}
                className="glass-strong border-glow rounded-2xl p-6">
                <I className="size-7 text-primary" />
                <h3 className="mt-4 font-display text-lg font-semibold text-gradient">{t}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{d}</p>
              </div>
            ))}
          </div>

          {/* International Opportunities & Recruiters Panel — special spotlight */}
          <div className="mt-16 relative rounded-3xl p-8 sm:p-12 overflow-hidden border-glow glass-strong">
            <div className="absolute -top-24 -right-24 size-72 rounded-full bg-primary/30 blur-3xl" />
            <div className="absolute -bottom-24 -left-24 size-72 rounded-full bg-accent/30 blur-3xl" />
            <div className="relative grid lg:grid-cols-[1.1fr_1fr] gap-10 items-center">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-3 py-1.5 text-[10px] font-extrabold tracking-[0.3em] uppercase text-primary-foreground">
                  <Globe className="size-3" /> Flagship Track
                </div>
                <h2 className="mt-4 font-display text-3xl sm:text-5xl font-extrabold leading-tight">
                  International <span className="text-gradient-primary">Opportunities</span> & Recruiters Panel
                </h2>
                <p className="mt-4 text-foreground/85 text-base sm:text-lg leading-relaxed font-medium">
                  A dedicated wing of the Employment Zone for global careers. Work-visa-friendly roles across
                  <span className="font-bold"> UAE · Singapore · Germany · United Kingdom · Canada</span> — plus an
                  on-stage panel where international recruiters interview, evaluate and roll out cross-border offers, live.
                </p>
                <div className="mt-6 grid sm:grid-cols-2 gap-3">
                  {[
                    "Country-wise visa & relocation briefings",
                    "Live international interview cabins",
                    "Cross-border salary benchmarking",
                    "On-spot offer letters with global employers",
                  ].map((p) => (
                    <div key={p} className="flex items-start gap-2 text-sm text-foreground/90">
                      <Sparkles className="size-4 text-primary shrink-0 mt-0.5" /> {p}
                    </div>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { flag: "🇦🇪", c: "UAE" },
                  { flag: "🇸🇬", c: "Singapore" },
                  { flag: "🇩🇪", c: "Germany" },
                  { flag: "🇬🇧", c: "United Kingdom" },
                  { flag: "🇨🇦", c: "Canada" },
                  { flag: "🌐", c: "Global" },
                ].map((x) => (
                  <div key={x.c} className="glass border-glow rounded-2xl p-4 text-center">
                    <div className="text-3xl">{x.flag}</div>
                    <div className="mt-2 text-xs font-extrabold tracking-wide">{x.c}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Two-Day Agenda */}
          <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { day: "Day 01 · 20 January", focus: "Sourcing, Screening & Skill Validation", items: AGENDA_D1 },
                { day: "Day 02 · 21 January", focus: "Fast-Track Selection & Spot Job Offers", items: AGENDA_D2 },
                { day: "Day 03 · 22 January", focus: "Offer Letter Distribution Ceremony", items: AGENDA_D3 },
              ].map((seg) => (
              <div key={seg.day} className="glass-strong border-glow rounded-3xl p-6 sm:p-8">
                <div className="text-[10px] tracking-[0.3em] uppercase text-primary font-extrabold">{seg.day}</div>
                <h3 className="mt-2 font-display text-2xl font-extrabold text-gradient">{seg.focus}</h3>
                <ul className="mt-5 space-y-3">
                  {seg.items.map((a, i) => (
                    <li key={a.time}
                      className="glass rounded-xl p-4">
                      <div className="flex flex-wrap items-baseline gap-3">
                        <div className="font-mono text-xs text-primary font-bold whitespace-nowrap">{a.time}</div>
                        <div className="text-sm text-foreground font-bold">{a.title}</div>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground leading-relaxed">{a.d}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link to="/" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm">
              ← Back to Zenith
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
