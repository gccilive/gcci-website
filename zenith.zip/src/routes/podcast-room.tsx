import { createFileRoute, Link } from "@tanstack/react-router";
import { Mic2, Lightbulb, Wrench, Radio, Brain, Shield, Mail } from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { SocialSidebar } from "@/components/fest/SocialSidebar";
import { Footer } from "@/components/fest/Footer";
import aiWeek from "@/assets/ai-week.webp";
import cyberWeek from "@/assets/cyber-week.webp";

export const Route = createFileRoute("/podcast-room")({
  component: Page,
  head: () => ({
    meta: [
      { title: "Podcast Room · Zenith 2027" },
      { name: "description", content: "Big Tech Talk Show, Ideathon — Architect of Tomorrow, and live workshops streamed from the Zenith Podcast Room." },
    ],
  }),
});

const SHOWS = [
  {
    I: Mic2,
    title: "Big Tech Talk Show",
    sub: "Live · Day 01 — 02 — 03",
    d: "Founders, scientists and creators face the mic. Recorded live in front of a studio audience and streamed to 20+ countries.",
  },
  {
    I: Lightbulb,
    title: "Ideathon",
    sub: "Architect of Tomorrow",
    d: "A 36-hour open ideation marathon. Students, teachers and founders co-architect solutions for India 2035 — judged live on the podcast stage.",
  },
  {
    I: Wrench,
    title: "Workshops",
    sub: "Hands-on · All 3 days",
    d: "Drone building, prompt engineering, robotics, full-stack and design sprints. Limited-seat workshops with industry mentors.",
  },
];

const AI_WEEK_BULLETS = [
  "Sessions exploring the latest advances in cybersecurity technology.",
  "World-class expertise paired with actionable innovation.",
  "Deep-dive sessions and high-level networking with the global cyber community.",
  "A unique gathering of experts, startups, investors, academics, diplomats and government officials.",
];

const SCHEDULE = [
  { time: "Day 01 · 11:00", title: "Big Tech Talk Show — opening episode" },
  { time: "Day 01 · 15:00", title: "Workshop · Build your first AI agent (90 min)" },
  { time: "Day 02 · 10:00", title: "Ideathon kick-off — Architect of Tomorrow" },
  { time: "Day 02 · 14:00", title: "Workshop · FPV drone build + flight (120 min)" },
  { time: "Day 02 · 17:00", title: "Big Tech Talk Show — Founders edition" },
  { time: "Day 03 · 11:00", title: "Ideathon final pitches · live podcast" },
  { time: "Day 03 · 15:00", title: "Workshop · Ship a SaaS in 3 hours" },
];

function Page() {
  return (
    <div className="relative min-h-screen bg-hero">
      <Nav />
      <SocialSidebar />
      <main className="pt-32 pb-24 px-4 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase">
              <Radio className="size-3 text-primary animate-pulse" /> Live · Studio 1 · Indira Gandhi Pratishthan, Lucknow
            </div>
            <h1 className="mt-6 font-display text-5xl sm:text-7xl font-bold leading-[1.05]">
              The <span className="text-gradient-primary">Podcast</span> Room
            </h1>
            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
              Home of the Big Tech Talk Show, the Ideathon — Architect of Tomorrow — and the Zenith
              workshop series. All three streamed live across 20th, 21st, 22nd January 2027.
            </p>
          </div>

          <div className="mt-14 grid lg:grid-cols-3 gap-5">
            {SHOWS.map(({ I, title, sub, d }, i) => (
              <div key={title}
                className="glass-strong border-glow rounded-2xl p-6 relative overflow-hidden">
                <div className="absolute -right-10 -top-10 size-32 rounded-full bg-gradient-to-br from-primary to-accent opacity-20 blur-2xl" />
                <I className="size-8 text-primary relative" />
                <div className="text-[10px] tracking-[0.25em] uppercase text-muted-foreground mt-4">{sub}</div>
                <h3 className="mt-1 font-display text-2xl font-bold text-gradient">{title}</h3>
                <p className="mt-3 text-sm text-muted-foreground leading-relaxed">{d}</p>
              </div>
            ))}
          </div>

          <div className="mt-16 glass-strong border-glow rounded-3xl p-6 sm:p-10">
            <h2 className="font-display text-2xl font-bold mb-6">Live Schedule</h2>
            <ul className="space-y-3">
              {SCHEDULE.map((a, i) => (
                <li key={a.time}
                  className="flex gap-4 items-start glass rounded-xl p-4">
                  <div className="font-mono text-xs text-primary w-28 shrink-0">{a.time}</div>
                  <div className="text-sm text-foreground/90">{a.title}</div>
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-12 text-center">
            <Link to="/" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm">
              ← Back to Zenith
            </Link>
          </div>

          {/* AI Week */}
          <section id="ai-week" className="mt-24 scroll-mt-32">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="rounded-3xl overflow-hidden border-glow glass-strong">
                <img decoding="async" src={aiWeek} alt="AI Week poster" loading="eager" className="w-full h-auto" />
              </div>
              <div>
                <div className="inline-flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-primary font-bold">
                  <Brain className="size-3.5" /> AI Week
                </div>
                <h2 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold text-gradient-primary leading-tight">
                  The cornerstone of the global security conversation.
                </h2>
                <p className="mt-4 text-foreground/85 leading-relaxed">
                  AI Week brings together industry leaders, decision-makers and experts from across the globe with an extensive
                  lineup of conferences, seminars and roundtables — an unparalleled opportunity to network with the entire cyber
                  ecosystem, including industry, startups, investors, academia, government and the military.
                </p>
                <div className="mt-5 glass border-glow rounded-2xl p-5">
                  <div className="text-[11px] tracking-[0.25em] uppercase text-primary font-extrabold">What to expect</div>
                  <ul className="mt-3 space-y-2 text-sm">
                    {AI_WEEK_BULLETS.map((t) => (
                      <li key={t} className="flex gap-2 items-start">
                        <span className="mt-1.5 size-1.5 rounded-full bg-primary shrink-0" />{t}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-4 glass border-glow rounded-2xl p-5">
                  <div className="text-[11px] tracking-[0.25em] uppercase text-primary font-extrabold">Join the AI Week Team</div>
                  <p className="mt-2 text-sm text-foreground/85">
                    Passionate about cybersecurity? Help shape promotion, event management and content for AI Week.
                  </p>
                  <a href="mailto:info@gcci.live" className="mt-3 inline-flex items-center gap-2 text-sm font-bold text-primary">
                    <Mail className="size-4" /> Send your CV → info@gcci.live
                  </a>
                </div>
              </div>
            </div>
          </section>

          {/* Cyber Week */}
          <section id="cyber-week" className="mt-24 scroll-mt-32">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="lg:order-2 rounded-3xl overflow-hidden border-glow glass-strong">
                <img decoding="async" src={cyberWeek} alt="Cyber Week poster" loading="eager" className="w-full h-auto" />
              </div>
              <div className="lg:order-1">
                <div className="inline-flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-primary font-bold">
                  <Shield className="size-3.5" /> Cyber Week
                </div>
                <h2 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold text-gradient leading-tight">
                  The cornerstone of the global security conversation.
                </h2>
                <p className="mt-4 text-foreground/85 leading-relaxed">
                  Cyber Week brings together industry leaders, decision-makers and experts from across the globe with an extensive
                  lineup of conferences, seminars and roundtables — an unparalleled opportunity to network with the entire cyber
                  ecosystem, including industry, startups, investors, academia, government and the military.
                </p>
                <div className="mt-5 glass border-glow rounded-2xl p-5">
                  <div className="text-[11px] tracking-[0.25em] uppercase text-primary font-extrabold">What to expect</div>
                  <ul className="mt-3 space-y-2 text-sm">
                    {[
                      "Sessions exploring the latest advances in cybersecurity technology.",
                      "World-class expertise paired with actionable innovation.",
                      "Deep-dive sessions and high-level networking with the global cyber community.",
                      "A unique gathering of experts, startups, investors, academics, diplomats and government officials.",
                    ].map((t) => (
                      <li key={t} className="flex gap-2 items-start">
                        <span className="mt-1.5 size-1.5 rounded-full bg-accent shrink-0" />{t}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-4 glass border-glow rounded-2xl p-5">
                  <div className="text-[11px] tracking-[0.25em] uppercase text-primary font-extrabold">Join the Cyber Week Team</div>
                  <p className="mt-2 text-sm text-foreground/85">
                    Passionate about cybersecurity? Help shape promotion, event management and content for Cyber Week.
                  </p>
                  <a href="mailto:info@gcci.live" className="mt-3 inline-flex items-center gap-2 text-sm font-bold text-primary">
                    <Mail className="size-4" /> Send your CV → info@gcci.live
                  </a>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </div>
  );
}
