import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Trophy, Star, Award, Sparkles, Cpu, Heart, Users, Medal,
  Rocket, Building2, Lightbulb, Palette, Globe2, Brain,
} from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { SocialSidebar } from "@/components/fest/SocialSidebar";
import { Footer } from "@/components/fest/Footer";

export const Route = createFileRoute("/awards")({
  component: AwardsPage,
  head: () => ({
    meta: [
      { title: "Awards · Zenith — Global Youth Tech Festival 2027" },
      { name: "description", content: "The Zenith Awards 2027 — 20+ categories spanning project, impact, participant, youth, corporate, festival and innovation honours." },
    ],
  }),
});

type AwardItem = { title: string; desc: string };
type AwardCategory = {
  id: string;
  number: string;
  emoji?: string;
  title: string;
  tagline: string;
  icon: typeof Trophy;
  accent: "primary" | "accent" | "destructive";
  items: AwardItem[];
};

const CATEGORIES: AwardCategory[] = [
  {
    id: "project-technical",
    number: "01",
    title: "Project & Technical Awards",
    tagline: "The “What” they built",
    icon: Cpu,
    accent: "primary",
    items: [
      { title: "Best Overall Innovation", desc: "Project that most effectively combines technical complexity with market feasibility or practical use." },
      { title: "Best Technical Solution", desc: "Honours advanced coding, innovative algorithms or highly complex system architecture." },
      { title: "Best UX / UI Design", desc: "The most intuitive, user-friendly and visually engaging interface of the festival." },
      { title: "Best Use of AI / Emerging Tech", desc: "Most creative and impactful use of frontier tech — Generative AI, IoT, Web3 and beyond." },
    ],
  },
  {
    id: "thematic-impact",
    number: "02",
    title: "Thematic & Impact Awards",
    tagline: "The “Why” they built it",
    icon: Heart,
    accent: "destructive",
    items: [
      { title: "Social & Humanitarian Impact", desc: "Tech solving pressing societal issues across healthcare, education and accessibility." },
      { title: "Climate & Sustainability Tech", desc: "Innovations in environmental conservation, carbon reduction or renewable energy." },
      { title: "Best Youth Startup", desc: "Working prototype with a viable business model, pitch deck and revenue roadmap." },
    ],
  },
  {
    id: "participant-soft",
    number: "03",
    title: "Participant & Soft-Skill Awards",
    tagline: "The “How” they collaborated",
    icon: Users,
    accent: "accent",
    items: [
      { title: "Pitch Perfect Award", desc: "Most compelling, persuasive and engaging project demonstration to the judges." },
      { title: "Dream Team Award", desc: "Exceptional collaboration, communication and adaptability within a team." },
      { title: "Audience Choice", desc: "Voted on by festival attendees and the online viewing community." },
    ],
  },
  {
    id: "special",
    number: "04",
    title: "Special Accolades",
    tagline: "Wildcards & mentor honours",
    icon: Medal,
    accent: "primary",
    items: [
      { title: "Rising Star / Best Rookie Team", desc: "Exceptional promise and innovation from first-time participants or younger age groups." },
      { title: "Mentor of the Year", desc: "Educator, industry professional or volunteer who went above and beyond to guide students." },
    ],
  },
  {
    id: "youth-student",
    number: "05",
    emoji: "🌟",
    title: "Youth & Student Innovators",
    tagline: "The next generation of builders",
    icon: Rocket,
    accent: "destructive",
    items: [
      { title: "Tech for Good Impact Award", desc: "Youth-led projects solving real-world sustainability or humanitarian problems with AI, IoT or clean tech." },
      { title: "Next-Gen Coder / Developer Prize", desc: "Under-25 individual or team with exceptional technical complexity and coding ability across the hackathons." },
      { title: "Best Pitch / Young Entrepreneur", desc: "Youth-led startup with the most compelling business model, scalability and investor potential." },
    ],
  },
  {
    id: "corporate",
    number: "06",
    emoji: "🤝",
    title: "Corporate & Ecosystem Excellence",
    tagline: "Industry champions of youth tech",
    icon: Building2,
    accent: "accent",
    items: [
      { title: "Youth Empowerment Champion", desc: "Corporate partner that has done the most to upskill, hire or mentor young tech talent." },
      { title: "Best Collaborative Hackathon Project", desc: "Winning corporate-university team that successfully built a viable prototype together at the festival." },
      { title: "Corporate Innovation in Tech", desc: "Established company that has developed or sponsored the most groundbreaking, youth-centric platform." },
    ],
  },
  {
    id: "festival-pitching",
    number: "07",
    emoji: "🏆",
    title: "Festival & Pitching Special Awards",
    tagline: "The unmissable on-stage moments",
    icon: Trophy,
    accent: "primary",
    items: [
      { title: "The Disruptor Award", desc: "Boldest, most unconventional project or idea that fundamentally challenges existing industry norms." },
      { title: "Design Thinking Hero", desc: "Best user-centric design, UI/UX and accessibility in a tech solution." },
      { title: "Community Choice Award", desc: "Voted on by festival attendees to recognise the most inspiring or popular project of the event." },
    ],
  },
  {
    id: "innovation-tech",
    number: "08",
    title: "Innovation & Tech Development",
    tagline: "Organisations shaping what comes next",
    icon: Lightbulb,
    accent: "destructive",
    items: [
      { title: "Youth Tech Trailblazer Award", desc: "Company that has developed groundbreaking digital tools or tech specifically for young users or students." },
      { title: "Excellence in Applied AI / Emerging Tech", desc: "Organisations effectively utilising AI, IoT or Blockchain to solve global challenges." },
      { title: "Best Digital Creativity Award", desc: "Companies that merge technology with arts, media or creative entertainment." },
    ],
  },
];

const ITEM_ICONS = [Star, Brain, Palette, Rocket, Globe2, Lightbulb, Award, Medal];

const ACCENT_RING: Record<AwardCategory["accent"], string> = {
  primary: "from-primary/30 to-accent/20",
  accent: "from-accent/30 to-primary/20",
  destructive: "from-destructive/30 to-primary/20",
};

const STATS = [
  { value: "25+", label: "Award Categories" },
  { value: "8", label: "Themed Tracks" },
  { value: "₹1Cr +", label: "Global Investor Pool" },
];

function AwardsPage() {
  return (
    <div className="relative min-h-screen bg-hero">
      <Nav />
      <SocialSidebar />
      <main className="pt-32 pb-24 px-4 sm:px-6">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase">
              <Sparkles className="size-3 text-primary" /> Zenith Awards · January 22, 2027
            </div>
            <h1 className="mt-6 font-display text-5xl sm:text-7xl font-extrabold leading-[1.05]">
              The <span className="text-gradient-primary">Zenith</span> Awards
            </h1>
            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto text-base sm:text-lg">
              Eight tracks. Twenty-five honours. One stage at the Indira Gandhi Pratishthan on the closing night of the
              Global Youth Tech Festival — celebrating the <span className="font-semibold text-foreground">what</span>,
              the <span className="font-semibold text-foreground">why</span> and the <span className="font-semibold text-foreground">how</span> of youth-built technology.
            </p>

            <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 gap-3 max-w-3xl mx-auto">
              {STATS.map((s) => (
                <div key={s.label} className="glass border-glow rounded-2xl p-4">
                  <div className="font-display text-2xl sm:text-3xl font-extrabold text-gradient-primary">{s.value}</div>
                  <div className="text-[11px] mt-1 tracking-[0.18em] uppercase text-muted-foreground">{s.label}</div>
                </div>
              ))}
            </div>

            {/* Quick category nav */}
            <div className="mt-10 flex flex-wrap justify-center gap-2">
              {CATEGORIES.map((c) => (
                <a key={c.id} href={`#${c.id}`}
                  className="glass rounded-full px-3.5 py-1.5 text-xs font-semibold hover:bg-primary/10 transition-colors">
                  <span className="text-primary mr-1.5">{c.number}</span>{c.emoji ? `${c.emoji} ` : ""}{c.title.split(" & ")[0]}
                </a>
              ))}
            </div>
          </div>

          <div className="mt-20 space-y-16">
            {CATEGORIES.map((cat, ci) => {
              const Icon = cat.icon;
              return (
                <section key={cat.id} id={cat.id} className="scroll-mt-28">
                  <div
                    className="relative glass-strong border-glow rounded-3xl p-6 sm:p-10 overflow-hidden">
                    <div className={`absolute -top-24 -right-24 size-64 rounded-full bg-gradient-to-br ${ACCENT_RING[cat.accent]} blur-3xl opacity-70 pointer-events-none`} />
                    <div className="relative flex flex-col sm:flex-row sm:items-end gap-4 sm:gap-6 mb-8">
                      <div className="flex items-center gap-4">
                        <div className="size-14 rounded-2xl bg-gradient-to-br from-primary to-accent grid place-items-center text-primary-foreground glow-sm">
                          <Icon className="size-7" />
                        </div>
                        <div className="font-display text-5xl sm:text-6xl font-extrabold text-gradient-primary leading-none">
                          {cat.number}
                        </div>
                      </div>
                      <div className="flex-1">
                        <h2 className="font-display text-2xl sm:text-4xl font-extrabold leading-tight">
                          {cat.emoji && <span className="mr-2">{cat.emoji}</span>}{cat.title}
                        </h2>
                        <p className="mt-1 text-sm sm:text-base text-muted-foreground italic">{cat.tagline}</p>
                      </div>
                      <div className="hidden sm:block text-xs tracking-[0.3em] uppercase text-muted-foreground">
                        {cat.items.length} Honours
                      </div>
                    </div>

                    <div className="relative grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {cat.items.map((a, i) => {
                        const ItemIcon = ITEM_ICONS[(ci + i) % ITEM_ICONS.length];
                        return (
                          <div key={a.title}
                            className="group glass border-glow rounded-2xl p-5 hover:-translate-y-1 transition-transform">
                            <div className="flex items-start gap-3">
                              <div className="size-9 shrink-0 rounded-xl bg-primary/10 grid place-items-center group-hover:bg-primary/20 transition-colors">
                                <ItemIcon className="size-4 text-primary" />
                              </div>
                              <div>
                                <h3 className="font-display text-base font-bold text-gradient leading-tight">{a.title}</h3>
                                <p className="mt-1.5 text-xs text-muted-foreground leading-relaxed">{a.desc}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </section>
              );
            })}
          </div>

          {/* Call to action */}
          <div
            className="mt-20 glass-strong border-glow rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-accent/10 to-destructive/10 pointer-events-none" />
            <div className="relative">
              <Sparkles className="size-7 text-primary mx-auto" />
              <h3 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold">
                Nominations open <span className="text-gradient-primary">Spring 2027</span>
              </h3>
              <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
                Self-nominate, nominate a peer or back a young founder. Shortlists announced November 2026 —
                winners revealed live on closing night, January 22nd 2027.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <Link to="/" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm">
              ← Back to Zenith
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
