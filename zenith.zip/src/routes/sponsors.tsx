import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Mail, Eye, Globe2, Lightbulb, Users, Handshake, Megaphone, Rocket, Trophy, Newspaper, Network } from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { Footer } from "@/components/fest/Footer";

export const Route = createFileRoute("/sponsors")({
  component: SponsorsPage,
  head: () => ({
    meta: [
      { title: "Sponsorship · Zenith — GYTF India 2027" },
      { name: "description", content: "Sponsor Zenith 2027. Title, Platinum, Gold & Silver tiers with full benefits breakdown. Reach 10K+ attendees, 200+ exhibitors and a global stage." },
      { property: "og:title", content: "Sponsorship · Zenith — GYTF India 2027" },
      { property: "og:description", content: "Tier-by-tier sponsorship benefits & partner logos for Zenith 2027, Lucknow." },
    ],
  }),
});

const PARTNERS = [
  { name: "Microsoft", domain: "microsoft.com" },
  { name: "Google",    domain: "google.com" },
  { name: "Amazon",    domain: "amazon.com" },
  { name: "IBM",       domain: "ibm.com" },
  { name: "Oracle",    domain: "oracle.com" },
  { name: "Adobe",     domain: "adobe.com" },
  { name: "Accenture", domain: "accenture.com" },
  { name: "Deloitte",  domain: "deloitte.com" },
  { name: "TCS",       domain: "tcs.com" },
  { name: "Infosys",   domain: "infosys.com" },
  { name: "Wipro",     domain: "wipro.com" },
  { name: "Capgemini", domain: "capgemini.com" },
];

const REASONS = [
  { icon: Eye,        title: "High Visibility",          desc: "Showcase your brand on the main stage to 10,000+ targeted attendees across three cinematic days — backdrop, lanyards, broadcast." },
  { icon: Globe2,     title: "Global Exposure",          desc: "Engage attendees, founders and exhibitors from 20+ countries — an international platform for your products and your story." },
  { icon: Lightbulb,  title: "Innovative Exhibits",      desc: "Stand alongside frontier AI, robotics, space, drones and cybersecurity demos that command the floor and the cameras." },
  { icon: Network,    title: "Networking Opportunities", desc: "Connect with industry leaders, ministry officers, CXOs, investors and collaborators in curated lounges and side-rooms." },
  { icon: Users,      title: "1-2-1 Mentorship",         desc: "Direct sessions with global business experts. Real insights, real strategies to grow your category presence." },
  { icon: Megaphone,  title: "Press & Broadcast Reach",  desc: "Featured in coverage by NDTV, Aaj Tak, India Today, The Hindu, PTI, ANI, CNN-News18 and 20+ national newsrooms." },
  { icon: Trophy,     title: "Award & Honour Moments",   desc: "Co-present student awards, hackathon trophies or innovation honours — your brand attached to a moment that matters." },
  { icon: Handshake,  title: "Government & Diplomatic Access", desc: "Direct introductions to ministry officials, embassies and trade-body representatives invited to Zenith 2027." },
  { icon: Rocket,     title: "Talent Pipeline",          desc: "Pre-vetted access to 5,000+ engineers, designers and founders on-floor — internships, placements, recruitment, all-in." },
  { icon: Newspaper,  title: "Souvenir & Co-branded IP", desc: "Featured in the official Zenith souvenir, distributed online and offline across India and partner nations." },
];

function SponsorsPage() {
  return (
    <div className="relative min-h-screen">
      <Nav />
      <main className="pt-28">
        {/* Hero */}
        <section className="relative px-4 sm:px-6 pb-16">
          <div className="mx-auto max-w-7xl">
            <Link to="/" className="inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition">
              <ArrowLeft className="size-3" /> Back to Zenith
            </Link>
            <div
              className="mt-6 max-w-4xl"
            >
              <div className="text-xs tracking-[0.3em] uppercase text-muted-foreground">Partner with Zenith</div>
              <h1 className="mt-3 font-display text-5xl sm:text-7xl font-bold leading-[0.95]">
                Build the future <span className="text-gradient">in front of</span> 10,000+ attendees.
              </h1>
              <p className="mt-6 text-lg text-muted-foreground max-w-2xl leading-relaxed">
                Three cinematic days. 20+ speakers. 200+ exhibitors. A global press pool.
                Pick the tier that matches your ambition.
              </p>
            </div>
          </div>
        </section>

        {/* Partners logo wall */}
        <section className="relative px-4 sm:px-6 pb-20">
          <div className="mx-auto max-w-7xl">
            <div className="text-xs tracking-[0.3em] uppercase text-muted-foreground mb-6">Trusted by</div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {PARTNERS.map((p, i) => (
                <div
                  key={p.name}
                  className="glass border-glow rounded-2xl p-5 flex items-center justify-center hover:scale-[1.03] transition"
                >
                  <div className="font-display text-sm tracking-widest">{p.name.toUpperCase()}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Exhibit or Sponsor — creative pointers */}
        <section className="relative px-4 sm:px-6 pb-24">
          <div className="mx-auto max-w-7xl">
            <div className="text-center max-w-3xl mx-auto mb-12">
              <div className="text-xs tracking-[0.3em] uppercase text-primary font-bold">Why Exhibit or Sponsor</div>
              <h2 className="mt-3 font-display text-4xl sm:text-5xl font-extrabold leading-tight">
                Ten reasons brands <span className="text-gradient">choose Zenith</span>.
              </h2>
              <p className="mt-4 text-muted-foreground">
                Custom co-creation, category-exclusive packages and regional editions are available on request — we build the partnership around your goals, not a price card.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {REASONS.map((r, i) => {
                const Icon = r.icon;
                return (
                  <div
                    key={r.title}
                    className="glass-strong border-glow rounded-2xl p-6 relative overflow-hidden group hover:-translate-y-1 transition"
                  >
                    <div className="absolute -right-10 -top-10 size-32 rounded-full bg-gradient-to-br from-primary/25 to-accent/25 blur-2xl opacity-0 group-hover:opacity-100 transition" />
                    <div className="relative size-12 rounded-xl bg-gradient-to-br from-primary to-accent grid place-items-center glow-sm mb-4">
                      <Icon className="size-6 text-primary-foreground" />
                    </div>
                    <div className="relative text-[10px] tracking-[0.3em] uppercase text-primary font-bold">{String(i + 1).padStart(2, "0")}</div>
                    <h3 className="relative mt-1 font-display text-xl font-extrabold text-gradient">{r.title}</h3>
                    <p className="relative mt-2 text-sm text-foreground/85 leading-relaxed font-medium">{r.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="relative px-4 sm:px-6 pb-32">
          <div className="mx-auto max-w-5xl glass-strong border-glow rounded-3xl p-10 sm:p-16 text-center relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 pointer-events-none" />
            <div className="relative">
              <div className="text-xs tracking-[0.3em] uppercase text-muted-foreground">Let's talk</div>
              <h2 className="mt-3 font-display text-3xl sm:text-5xl font-bold leading-tight">
                Be the brand that <span className="text-gradient">powers</span> Zenith 2027.
              </h2>
              <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
                Tell us about your goals — we'll come back with a tailored proposal within 48 hours.
              </p>
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <a
                  href="mailto:info@gcci.live"
                  className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm hover:opacity-95 transition"
                >
                  <Mail className="size-4" /> info@gcci.live
                </a>
                <Link
                  to="/"
                  className="inline-flex items-center gap-2 rounded-full glass border-glow px-6 py-3 text-sm font-semibold hover:bg-white/5 transition"
                >
                  Back to home
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
