import { createFileRoute, Link } from "@tanstack/react-router";
import {
  HandHeart, Award, Users, Calendar, Clock, MapPin, Mail, Phone, ShieldCheck,
  Sparkles, ClipboardList, UserCheck, Headphones, Camera, Megaphone, Truck,
  Building2, Wifi, Coffee, Mic2, Info, Star,
} from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { SocialSidebar } from "@/components/fest/SocialSidebar";
import { Footer } from "@/components/fest/Footer";
import { SectionHeader } from "@/components/fest/SectionHeader";

export const Route = createFileRoute("/volunteers")({
  component: Page,
  head: () => ({
    meta: [
      { title: "Volunteer Programme · Zenith — Global Youth Tech & Innovation Summit 2027" },
      { name: "description", content: "Join the Volunteer Programme of Zenith — Global Youth Tech & Innovation Summit 2027. Bronze, Silver, Gold tiers · 11 mission-critical roles · certificates & honorariums." },
    ],
  }),
});

const TIERS = [
  { name: "Bronze", desc: "Part-time commitment. Perfect for college students juggling academics with on-ground action.", glow: "from-amber-700/40 to-amber-500/40" },
  { name: "Silver", desc: "Hybrid commitment. Deeper involvement, more rotations across departments and visibility.", glow: "from-slate-300/40 to-slate-100/40" },
  { name: "Gold",   desc: "Full-time commitment. Lead-track volunteers embedded with department heads end-to-end.", glow: "from-yellow-500/50 to-amber-300/50" },
];

const ROLES = [
  { I: UserCheck,   t: "Registration",                d: "Receive the audience, check ID cards and documents. You are the 'face' of the summit — first contact with audiences and speakers. Tech-savvy, quick to learn, calm under pressure and a professional demeanor are essential." },
  { I: Truck,       t: "Logistics — Transport & Stay", d: "Manage guest travel itineraries, arrange pickups and drop-offs, ensure accommodation readiness. Quick on your feet, problem-solving and consistently courteous." },
  { I: Info,        t: "Information Desk",            d: "Know every venue detail and schedule thoroughly. Stay updated on program changes. Professional knowledge paired with a helpful attitude is essential." },
  { I: Building2,   t: "Venue Management",            d: "Ensure assigned venues are ready before each session. Assist Venue Managers with crowd management. Smooth venue operations always come first." },
  { I: Mic2,        t: "Speakers Liaison",            d: "Based in the speakers' lounge. Embody 'Atithi Devo Bhava' — make speakers comfortable, relaxed and well-supported throughout the summit." },
  { I: Star,        t: "Exhibitors & Sponsor Management", d: "Coordinate with venue managers, technical staff and the exhibition team to ensure sponsor branding is displayed exactly as promised." },
  { I: Megaphone,   t: "Press & Media",               d: "Based at the Press Area, coordinate interviews with speakers alongside the Event PR team and keep the Press Terrace ready to receive guests." },
  { I: ShieldCheck, t: "Security",                    d: "Eyes and ears of the summit — smooth coordination between security personnel and attendees. Assist with VVIP visits and stay vigilant." },
  { I: Coffee,      t: "F&B and Lounge Management",   d: "Keep lounges well-stocked with refreshments, venues supplied with water and meals served on time." },
  { I: Camera,      t: "Social Media",                d: "Capture ambience, behind-the-scenes and key sessions for online content. Photography, advertising, branding or digital media backgrounds preferred." },
  { I: Wifi,        t: "IT & Technical",              d: "Ensure technical errors do not hamper the summit. Maintain continuous internet connectivity in close collaboration with IT representatives." },
];

const TERMS = [
  { I: Calendar,   t: "Registration Deadline",  d: "Volunteering registration is open until 11:00 PM, 10 November 2026." },
  { I: UserCheck,  t: "Age Requirement",        d: "Only applicants over 18 years old will be accepted." },
  { I: Headphones, t: "Personal Interview",     d: "An online interview will be conducted. Shortlisted applicants must know the summit's history, programmes and organisers." },
  { I: MapPin,     t: "Residency Preference",   d: "First preference goes to those residing in Lucknow. Volunteers from other cities arrange their own travel and accommodation." },
  { I: Mail,       t: "Communication",          d: "All key communication is via email. Applicants who fail to respond to emails or reminder calls will NOT be considered." },
  { I: ClipboardList, t: "Mandatory Training",  d: "A mandatory 2–3 day training programme will be held for all shortlisted applicants prior to the summit." },
  { I: Coffee,     t: "Lunch & Refreshments",   d: "Lunch will be provided to all volunteers at the summit venue." },
  { I: Award,      t: "Certificate & Honorarium", d: "The organiser will provide a certificate and a basic honorarium to acknowledge your effort." },
];

function Page() {
  return (
    <div className="relative min-h-screen bg-hero">
      <Nav />
      <SocialSidebar />
      <main className="pt-32 pb-24 px-4 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase">
              <HandHeart className="size-3 text-primary" /> Volunteer Programme · Zenith 2027
            </div>
            <h1 className="mt-6 font-display text-4xl sm:text-6xl font-extrabold leading-[1.05]">
              Be the <span className="text-gradient-primary">heartbeat</span> of the world's biggest youth summit.
            </h1>
            <div className="mt-6 inline-flex max-w-full items-center gap-3 rounded-full px-5 py-2.5 bg-gradient-to-r from-primary via-accent to-destructive text-primary-foreground font-extrabold tracking-[0.18em] uppercase text-sm sm:text-base glow shadow-lg animate-blink" style={{ animationDuration: "1.4s" }}>
              <Calendar className="size-4 shrink-0" />
              <span className="min-w-0">Nomination Last Date · 10<sup>th</sup> November 2026</span>
            </div>
            <p className="mt-5 text-foreground/85 max-w-3xl mx-auto text-base sm:text-lg leading-relaxed">
              Hailed as one of the greatest international convenings on Earth, the <span className="font-bold">Global Youth Tech &amp; Innovation Summit 2027</span> brings together
              Ambassadors, High Commissioners, Consul Generals, Ministers, Governors, Members of Parliament, Government Officers, Municipal Mayors, Business
              Leaders and thought leaders from across the globe. At the core of this summit are its treasured volunteers — fuelled by passion, dedication and commitment.
            </p>
          </div>

          {/* Tiers */}
          <section className="mt-16">
            <SectionHeader kicker="Volunteer Levels" title="Bronze · Silver · Gold Tiers." sub="Choose how deep you go. Tier up based on commitment level — part-time or full-time, you belong here." />
            <div className="grid md:grid-cols-3 gap-5">
              {TIERS.map((t, i) => (
                <div key={t.name}
                  className="relative glass-strong border-glow rounded-3xl p-7 overflow-hidden">
                  <div className={`absolute -right-12 -top-12 size-40 rounded-full bg-gradient-to-br ${t.glow} blur-2xl opacity-60`} />
                  <Award className="size-8 text-primary relative" />
                  <h3 className="mt-4 font-display text-3xl font-extrabold text-gradient">{t.name}</h3>
                  <p className="mt-3 text-sm text-foreground/85 leading-relaxed">{t.desc}</p>
                </div>
              ))}
            </div>

            {/* Ambassador Volunteer + Networking — spotlight */}
            <div className="mt-8 grid lg:grid-cols-2 gap-5">
              <div className="relative glass-strong border-glow rounded-3xl p-7 overflow-hidden">
                <div className="absolute -top-16 -right-16 size-60 rounded-full bg-primary/30 blur-3xl" />
                <div className="relative">
                  <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-3 py-1.5 text-[10px] font-extrabold tracking-[0.3em] uppercase text-primary-foreground">
                    <Sparkles className="size-3" /> Senior Track
                  </div>
                  <h3 className="mt-3 font-display text-2xl sm:text-3xl font-extrabold text-gradient">Ambassador Volunteer Role</h3>
                  <p className="mt-3 text-sm sm:text-base text-foreground/85 leading-relaxed">
                    A cohort of <span className="font-bold">15–20 senior volunteers</span> who mentor volunteer teams, receive enhanced certificates
                    and participate in exclusive networking opportunities.
                  </p>
                </div>
              </div>
              <div className="relative glass-strong border-glow rounded-3xl p-7 overflow-hidden">
                <div className="absolute -top-16 -left-16 size-60 rounded-full bg-accent/30 blur-3xl" />
                <div className="relative">
                  <div className="inline-flex items-center gap-2 rounded-full glass px-3 py-1.5 text-[10px] font-extrabold tracking-[0.3em] uppercase text-primary">
                    <Users className="size-3" /> Exclusive Networking
                  </div>
                  <h3 className="mt-3 font-display text-2xl sm:text-3xl font-extrabold text-gradient">Premium Dinners & Cocktails</h3>
                  <p className="mt-3 text-sm sm:text-base text-foreground/85 leading-relaxed">
                    Curated dinner and cocktail gatherings reserved for top-performing volunteers — celebrating outstanding contributions in style.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Commitment */}
          <section className="mt-20">
            <div className="glass-strong border-glow rounded-3xl p-7 sm:p-10 relative overflow-hidden">
              <div className="absolute -top-20 right-1/3 size-72 rounded-full bg-primary/20 blur-3xl" />
              <div className="relative grid md:grid-cols-[1fr_1.4fr] gap-8 items-center">
                <div>
                  <Clock className="size-9 text-primary" />
                  <h3 className="mt-3 font-display text-3xl font-extrabold text-gradient">A 45–50 Day Journey.</h3>
                </div>
                <p className="text-foreground/85 leading-relaxed">
                  For those ready to embark on this enriching journey — spanning training, the summit itself and culmination, approximately
                  <span className="font-bold"> 45–50 days</span> — we urge you to carefully review the Terms &amp; Conditions and all relevant details.
                  You must diligently follow every protocol of the selection process.
                </p>
              </div>
            </div>
          </section>

          {/* Terms */}
          <section className="mt-20">
            <SectionHeader kicker="Terms & Conditions" title="Read Carefully Before Applying." />
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {TERMS.map(({ I, t, d }, i) => {
                const isDeadline = t === "Registration Deadline";
                return (
                <div key={t}
                  className={`relative rounded-2xl p-5 ${isDeadline ? "bg-gradient-to-br from-primary/25 via-accent/20 to-destructive/25 border-2 border-primary glow animate-blink" : "glass border-glow"}`}
                  style={isDeadline ? { animationDuration: "1.6s" } : undefined}>
                  <I className={`size-6 ${isDeadline ? "text-foreground" : "text-primary"}`} />
                  <div className={`mt-3 text-sm font-extrabold ${isDeadline ? "text-gradient-primary text-base" : "text-foreground"}`}>{t}</div>
                  <p className={`mt-1.5 text-xs leading-relaxed ${isDeadline ? "text-foreground font-bold" : "text-muted-foreground"}`}>{d}</p>
                </div>
              );})}
            </div>
          </section>

          {/* Roles */}
          <section className="mt-20">
            <SectionHeader kicker="Volunteer Roles" title="11 Mission-Critical Departments." sub="Pick a role that fits your strengths — every one of them is the difference between a good event and a legendary one." />
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {ROLES.map(({ I, t, d }, i) => (
                <div key={t}
                  className="glass-strong border-glow rounded-2xl p-6 relative overflow-hidden">
                  <div className="absolute -right-10 -top-10 size-28 rounded-full bg-gradient-to-br from-primary to-accent opacity-20 blur-2xl" />
                  <I className="size-7 text-primary relative" />
                  <h3 className="mt-4 font-display text-lg font-extrabold text-gradient">{t}</h3>
                  <p className="mt-2 text-sm text-foreground/85 leading-relaxed">{d}</p>
                </div>
              ))}
            </div>
          </section>

          {/* Contact CTA */}
          <section className="mt-20 relative rounded-3xl p-8 sm:p-12 overflow-hidden glass-strong border-glow">
            <div className="absolute -top-20 left-1/4 size-80 rounded-full bg-primary/25 blur-3xl" />
            <div className="absolute -bottom-20 right-1/4 size-72 rounded-full bg-accent/25 blur-3xl" />
            <div className="relative grid lg:grid-cols-[1.2fr_1fr] gap-10 items-center">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-3 py-1.5 text-[10px] font-extrabold tracking-[0.3em] uppercase text-primary-foreground">
                  <HandHeart className="size-3" /> Apply Now
                </div>
                <h2 className="mt-4 font-display text-3xl sm:text-5xl font-extrabold leading-tight">
                  Ready to wear the <span className="text-gradient-primary">Zenith</span> volunteer badge?
                </h2>
                <p className="mt-4 text-foreground/85 leading-relaxed">
                  Drop us a line with your name, city, role preference and tier (Bronze / Silver / Gold). Our team will reach out within 48 hours.
                </p>
                <a href="mailto:info@gcci.live?subject=Zenith%202027%20Volunteer%20Application" className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-bold text-primary-foreground glow-sm">
                  <Mail className="size-4" /> Apply via Email
                </a>
              </div>
              <div className="glass border-glow rounded-2xl p-6">
                <div className="text-xs tracking-[0.3em] uppercase text-primary font-extrabold">Contact</div>
                <ul className="mt-4 space-y-3 text-sm text-foreground/90">
                  <li className="flex gap-3"><MapPin className="size-4 text-primary shrink-0 mt-0.5" /> Indira Gandhi Pratishthan, Lucknow, India</li>
                  <li className="flex gap-3"><Mail className="size-4 text-primary shrink-0 mt-0.5" /> info@gcci.live</li>
                  <li className="flex gap-3"><Phone className="size-4 text-primary shrink-0 mt-0.5" /> +91 5732413499 · 9411400557 </li>
                </ul>
              </div>
            </div>
          </section>

          <div className="mt-12 text-center">
            <Link to="/" className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm">
              ← Back to Zenith
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
