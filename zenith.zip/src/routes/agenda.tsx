import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  Calendar, Clock, MapPin, Sparkles, Trophy, Mic2, ArrowLeft, Star,
} from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { Footer } from "@/components/fest/Footer";

export const Route = createFileRoute("/agenda")({
  component: AgendaPage,
  head: () => ({
    meta: [
      { title: "Agenda · Zenith — Global Youth Tech Fest India 2027" },
      { name: "description", content: "Three-day Zenith agenda: keynotes, hackathons, AI battles, robotics finals, awards & afterparty. Jan 20-22, 2027 · Lucknow." },
      { property: "og:title", content: "Agenda · Zenith — GYTF India 2027" },
      { property: "og:description", content: "Full session-by-session schedule across three Zenith days in Lucknow." },
    ],
  }),
});

type Session = {
  time: string;
  title: string;
  venue: string;
  track: string;
  zenith?: boolean;
  desc?: string;
};

type Day = {
  id: string;
  label: string;
  date: string;
  theme: string;
  tagline: string;
  sessions: Session[];
};

const DAYS: Day[] = [
  {
    id: "day1",
    label: "Day 01",
    date: "Jan 20, 2027",
    theme: "Ignition",
    tagline: "The spark — where Zenith begins.",
    sessions: [
      { time: "08:00 – 09:30", title: "Delegate Check-in & Welcome Brews", venue: "North Atrium", track: "Hospitality" },
      { time: "09:30 – 10:15", title: "Opening Keynote — The Zenith Manifesto", venue: "Main Stage", track: "Keynote", zenith: true, desc: "The official curtain-raiser of Zenith 2027 — a cinematic address from the Global Tech Council." },
      { time: "10:30 – 11:30", title: "Inauguration: Future Classroom Dome", venue: "Innovation Wing", track: "Showcase" },
      { time: "11:45 – 13:00", title: "Panel — Youth, AI & The Next Decade", venue: "Main Stage", track: "Panel" },
      { time: "13:00 – 14:00", title: "Networking Lunch", venue: "Red Lounge", track: "Break" },
      { time: "14:00 – 15:30", title: "Hackathon 48 — Kickoff Ceremony", venue: "Hack Arena", track: "Competition", zenith: true, desc: "1,000 builders, 48 hours, Frontier bounties — the signature Zenith build sprint begins." },
      { time: "15:45 – 17:00", title: "Principals' Conclave — Roundtable I", venue: "Conclave Hall", track: "Education" },
      { time: "17:15 – 18:30", title: "AI Battles — Opening Round", venue: "Arena Stage", track: "Competition" },
      { time: "19:30 – 22:00", title: "Zenith Welcome Gala", venue: "Red Lounge", track: "Networking", zenith: true, desc: "Black-tie reception with global founders, ministers and the Zenith Council." },
    ],
  },
  {
    id: "day2",
    label: "Day 02",
    date: "Jan 21, 2027",
    theme: "Acceleration",
    tagline: "Momentum, velocity, collisions.",
    sessions: [
      { time: "08:30 – 09:30", title: "Morning Brews & Founders' Forum", venue: "Red Lounge", track: "Networking" },
      { time: "09:30 – 10:30", title: "Keynote — Frontier Models, Indian Builders", venue: "Main Stage", track: "Keynote" },
      { time: "10:45 – 12:30", title: "AI Battles — Main Stage Showdown", venue: "Main Stage", track: "Competition", zenith: true, desc: "Live model duels and prompt arenas with frontier labs. The Zenith signature spectacle." },
      { time: "12:30 – 13:30", title: "Lunch & Sponsor Walkthrough", venue: "Exhibitor Hall", track: "Break" },
      { time: "13:30 – 15:00", title: "Startup Pitching — Semifinals", venue: "Pitch Dome", track: "Competition" },
      { time: "15:15 – 16:30", title: "Cybersecurity CTF — Live Round", venue: "CTF Lab", track: "Competition" },
      { time: "16:45 – 18:00", title: "Drone Racing — League Finals", venue: "Sky Arena", track: "Competition" },
      { time: "18:30 – 20:00", title: "Fireside — Building At Zenith", venue: "Main Stage", track: "Keynote", zenith: true, desc: "An intimate cross-generational dialogue with the Zenith honorees." },
      { time: "21:00 – Late", title: "Investor After-Hours", venue: "Sky Lounge", track: "Networking" },
    ],
  },
  {
    id: "day3",
    label: "Day 03",
    date: "Jan 22, 2027",
    theme: "Zenith",
    tagline: "The summit — every story, one stage.",
    sessions: [
      { time: "09:00 – 10:00", title: "Hackathon 48 — Final Demos", venue: "Hack Arena", track: "Competition" },
      { time: "10:15 – 11:30", title: "Robotics Arena — Grand Finale", venue: "Robotics Pit", track: "Competition" },
      { time: "11:45 – 13:00", title: "Gaming Championship — Finals", venue: "Esports Dome", track: "Competition" },
      { time: "13:00 – 14:00", title: "Closing Lunch & Press Hour", venue: "Press Plaza", track: "Break" },
      { time: "14:00 – 15:30", title: "Startup Pitching — Grand Finale", venue: "Main Stage", track: "Competition", zenith: true, desc: "Top 5 startups pitch to a ₹10 Cr global investor coalition — a defining Zenith moment." },
      { time: "15:45 – 17:00", title: "Closing Keynote — Where Futures Begin", venue: "Main Stage", track: "Keynote" },
      { time: "17:30 – 19:30", title: "Zenith Awards Ceremony", venue: "Main Stage", track: "Ceremony", zenith: true, desc: "The crown jewel of GYTF — the Zenith trophies for the most extraordinary builders of the year." },
      { time: "20:00 – 23:00", title: "Closing Show & Afterparty", venue: "Sky Lounge", track: "Celebration", zenith: true, desc: "Live performances, surprise drops and the official Zenith afterparty." },
    ],
  },
];

function AgendaPage() {
  const [active, setActive] = useState(0);
  const day = DAYS[active];

  return (
    <div className="relative min-h-screen">
      <Nav />

      {/* Hero */}
      <section className="relative pt-36 pb-16 px-4 sm:px-6 overflow-hidden bg-hero">
        <div className="absolute inset-0 grid-bg" />
        <div className="absolute -top-20 left-1/4 size-[420px] rounded-full bg-primary/25 blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 size-[360px] rounded-full bg-accent/20 blur-[120px]" />

        <div className="relative mx-auto max-w-5xl text-center">
          <Link
            to="/"
            className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase text-muted-foreground hover:text-foreground transition"
          >
            <ArrowLeft className="size-3" /> Back to Zenith
          </Link>

          <h1 className="mt-6 font-display font-bold leading-[0.95] text-[clamp(2.5rem,7vw,5.5rem)]">
            <span className="block text-foreground">THE</span>
            <span className="block">
              <span className="text-gradient-primary">ZENITH</span>{" "}
              <span className="text-foreground">AGENDA</span>
            </span>
          </h1>

          <p className="mt-6 max-w-2xl mx-auto text-base sm:text-lg text-muted-foreground">
            Three cinematic days. Sixty hours of signal. Every keynote, every battle, every Zenith moment — mapped end to end.
          </p>

          <div className="mt-8 inline-flex flex-wrap items-center justify-center gap-3 text-xs">
            <span className="glass border-glow rounded-full px-4 py-2 inline-flex items-center gap-2">
              <Calendar className="size-3.5 text-primary" /> Jan 20 – 22, 2027
            </span>
            <span className="glass border-glow rounded-full px-4 py-2 inline-flex items-center gap-2">
              <MapPin className="size-3.5 text-primary" /> Lucknow, India
            </span>
            <span className="glass border-glow rounded-full px-4 py-2 inline-flex items-center gap-2">
              <Sparkles className="size-3.5 text-primary" /> Marked
              <span className="text-primary font-semibold">★ Zenith</span>
              moments
            </span>
          </div>
        </div>
      </section>

      {/* Day tabs */}
      <section className="relative px-4 sm:px-6">
        <div className="mx-auto max-w-5xl">
          <div className="glass-strong border-glow rounded-2xl p-2 grid grid-cols-3 gap-2">
            {DAYS.map((d, i) => {
              const isActive = i === active;
              return (
                <button
                  key={d.id}
                  onClick={() => setActive(i)}
                  className={`relative rounded-xl px-4 py-4 text-left transition ${
                    isActive ? "bg-gradient-to-br from-primary to-accent text-primary-foreground glow-sm" : "hover:bg-white/5"
                  }`}
                >
                  <div className={`text-[10px] tracking-[0.3em] uppercase ${isActive ? "text-primary-foreground/80" : "text-primary"}`}>
                    {d.label} · {d.date}
                  </div>
                  <div className={`mt-1 font-display text-lg sm:text-2xl font-bold ${isActive ? "" : "text-foreground"}`}>
                    {d.theme}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Active day */}
      <section className="relative py-16 px-4 sm:px-6">
        <div className="mx-auto max-w-5xl">
          <div
            key={day.id}
            className="mb-10 text-center"
          >
            <div className="text-[10px] tracking-[0.3em] uppercase text-primary">{day.label} · {day.date}</div>
            <h2 className="mt-2 font-display text-4xl sm:text-5xl font-bold text-gradient">{day.theme}</h2>
            <p className="mt-3 text-muted-foreground">{day.tagline}</p>
          </div>

          <div className="relative">
            <div className="absolute left-[18px] sm:left-[140px] top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-primary/60 to-transparent" />

            <div className="space-y-4">
              {day.sessions.map((s, i) => (
                <div
                  key={`${day.id}-${i}`}
                  className="relative pl-10 sm:pl-[170px]"
                >
                  {/* time chip */}
                  <div className="hidden sm:block absolute left-0 top-4 w-[120px] text-right">
                    <div className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock className="size-3 text-primary" /> {s.time}
                    </div>
                  </div>

                  {/* node */}
                  <div
                    className={`absolute left-[12px] sm:left-[134px] top-6 size-3 rounded-full ${
                      s.zenith ? "bg-primary glow-sm animate-pulse-glow" : "bg-primary/60"
                    }`}
                  />

                  <div
                    className={`relative rounded-2xl p-5 sm:p-6 transition ${
                      s.zenith
                        ? "glass-strong border-glow overflow-hidden"
                        : "glass border-glow"
                    }`}
                  >
                    {s.zenith && (
                      <>
                        <div className="absolute -right-10 -top-10 size-40 rounded-full bg-primary/30 blur-3xl pointer-events-none" />
                        <div className="absolute top-4 right-4 inline-flex items-center gap-1 text-[10px] tracking-[0.25em] uppercase text-primary">
                          <Star className="size-3 fill-primary" /> Zenith Moment
                        </div>
                      </>
                    )}

                    <div className="sm:hidden text-xs text-muted-foreground inline-flex items-center gap-1.5 mb-2">
                      <Clock className="size-3 text-primary" /> {s.time}
                    </div>

                    <div className="flex items-center gap-2 text-[10px] tracking-[0.25em] uppercase text-muted-foreground">
                      <TrackIcon track={s.track} />
                      {s.track}
                    </div>

                    <h3
                      className={`mt-2 font-display font-semibold leading-tight ${
                        s.zenith ? "text-2xl sm:text-3xl text-gradient-primary" : "text-lg sm:text-xl text-foreground"
                      }`}
                    >
                      {s.title}
                    </h3>

                    {s.desc && (
                      <p className="mt-2 text-sm text-foreground/80 leading-relaxed max-w-2xl">{s.desc}</p>
                    )}

                    <div className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                      <MapPin className="size-3 text-primary" /> {s.venue}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="relative py-20 px-4 sm:px-6">
        <div className="mx-auto max-w-4xl glass-strong border-glow rounded-3xl p-10 sm:p-14 text-center relative overflow-hidden">
          <div className="absolute -top-20 -left-20 size-80 rounded-full bg-primary/25 blur-[120px]" />
          <div className="absolute -bottom-20 -right-20 size-80 rounded-full bg-accent/25 blur-[120px]" />
          <div className="relative">
            <div className="text-[10px] tracking-[0.3em] uppercase text-primary">Your seat at Zenith</div>
            <h3 className="mt-4 font-display text-3xl sm:text-5xl font-bold text-gradient">
              Don't just watch the agenda. Live it.
            </h3>
            <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
              Limited delegate passes for Zenith 2027. Lock yours before the Ignition keynote sells out.
            </p>
            <Link
              to="/"
              hash="register"
              className="mt-7 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-7 py-3.5 text-sm font-semibold text-primary-foreground glow hover:scale-[1.02] transition"
            >
              Register for Zenith →
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function TrackIcon({ track }: { track: string }) {
  const t = track.toLowerCase();
  if (t.includes("keynote")) return <Mic2 className="size-3 text-primary" />;
  if (t.includes("competition")) return <Trophy className="size-3 text-primary" />;
  if (t.includes("ceremony")) return <Star className="size-3 text-primary" />;
  return <Sparkles className="size-3 text-primary" />;
}