
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  GraduationCap, Users, BookOpen, Globe2, Lightbulb, Handshake,
  Building2, Sparkles, Briefcase, HeartHandshake, Award, Target,
  BookMarked, Trophy, FileText, Calendar, CheckCircle2, Mail,
} from "lucide-react";
import { Nav } from "@/components/fest/Nav";
import { SocialSidebar } from "@/components/fest/SocialSidebar";
import { Footer } from "@/components/fest/Footer";

export const Route = createFileRoute("/principals-conclave")({
  component: Page,
  head: () => ({
    meta: [
      { title: "Principals Conclave · Zenith 2027" },
      {
        name: "description",
        content:
          "Principals Conclave at Zenith 2027 — heads of schools rethinking education for the AI era.",
      },
    ],
  }),
});

const AGENDA = [
  { time: "10:00", title: "Welcome & State of Indian Education 2027" },
  {
    time: "11:00",
    title: "Panel: AI in the Classroom — Policy, Practice, Pitfalls",
  },
  { time: "12:30", title: "Roundtables: Future Classroom Design" },
  {
    time: "14:30",
    title:
      "Keynote: The Architect School — preparing builders, not test-takers",
  },
  {
    time: "16:00",
    title: "Closed-door: NEP 2.0 implementation playbook",
  },
  { time: "17:30", title: "Signing of the Zenith Education Charter" },
];

const FOCUS_AREAS = [
  { I: Lightbulb, t: "Skill Development & Technology Adoption" },
  { I: Building2, t: "Government Support & Policies" },
  { I: Handshake, t: "Principals Round Table Discussions" },
  { I: BookOpen, t: "NEP 2020 Implementation" },
  { I: Sparkles, t: "Innovation in Education" },
  { I: Globe2, t: "International Collaboration" },
  { I: Briefcase, t: "Entrepreneurship & Employment Opportunities" },
  { I: HeartHandshake, t: "Diversity & Inclusion in Education" },
];

const DISCUSSIONS = [
  "Global placements",
  "Principals Round Table sessions",
  "Addressing international education opportunities",
  "Alignment of skill development with industry needs and emerging technologies",
];

const SUPPORTERS = [
  "Education Ministry, Uttar Pradesh",
  "Skill Development Mission",
  "Department of Science & Technology, U.P.",
  "Department of IT & Electronics, U.P.",
  "AICTE",
  "Other prominent institutions",
];

function Page() {
  return (
    <div className="relative min-h-screen bg-hero">
      <Nav />
      <SocialSidebar />

      <main className="pt-32 pb-24 px-4 sm:px-6">
        <div className="mx-auto max-w-5xl">
          {/* Hero Section */}
          <div
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase">
              <GraduationCap className="size-3 text-primary" />
              January 20 · Day 01 · Indira Gandhi Pratishthan, Lucknow
            </div>

            <h1 className="mt-6 font-display text-5xl sm:text-7xl font-bold leading-[1.05]">
              Principal&apos;s{" "}
              <span className="text-gradient-primary">Conclave</span>
            </h1>

            <div className="mt-5 inline-flex flex-wrap justify-center gap-3 text-xs sm:text-sm tracking-[0.3em] uppercase font-extrabold">
              <span className="glass border-glow rounded-full px-4 py-1.5 text-primary">
                Educate
              </span>
              <span className="glass border-glow rounded-full px-4 py-1.5 text-destructive">
                Innovate
              </span>
              <span className="glass border-glow rounded-full px-4 py-1.5 text-accent">
                Elevate
              </span>
            </div>

            <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
              Towards a sustainable future — a closed-door gathering of 20+
              school heads, academic deans and policy makers, rebuilding the
              curriculum for a generation that will architect tomorrow.
            </p>
          </div>

          {/* Intro Blocks */}
          <div className="mt-14 grid lg:grid-cols-2 gap-5">
            {[
              {
                h: "Introduction to the Principal Conclave",
                p: "The Principal Conclave is a pioneering platform that brings together renowned experts and key decision-makers from the education sector. It focuses on exploring emerging opportunities and challenges in skill development and technology adoption.",
              },
              {
                h: "Conclave's Core Objectives",
                p: "Helping students focus on academic, personal, social and career development — preparing them to achieve success in school, college and life beyond. The conclave aims to foster employment, entrepreneurship, and global opportunities within the education system.",
              },
              {
                h: "Exclusive Gathering of Education Leaders",
                p: "An invite-only space for universities, colleges, school principals, vice-principals, counselors, senior faculty and educationists to exchange ideas, discuss the impact of NEP 2020, and explore strategies to align education with industry requirements.",
              },
              {
                h: "Innovation, Collaboration & Networking",
                p: "The conclave emphasizes innovation, international collaboration, and sustainable initiatives — combined with insightful discussions, presentations and interactive sessions where institutions can showcase strengths and connect with top industry officials.",
              },
            ].map((b) => (
              <div
                key={b.h}
                className="glass border-glow rounded-2xl p-6"
              >
                <div className="text-[10px] tracking-[0.3em] uppercase text-primary">
                  {b.h}
                </div>
                <p className="mt-3 text-sm text-foreground/85 leading-relaxed">
                  {b.p}
                </p>
              </div>
            ))}
          </div>

          {/* Statistics */}
          <div className="mt-12 grid sm:grid-cols-3 gap-4">
            {[
              {
                I: Users,
                t: "20+ Principals",
                d: "from CBSE, ICSE, IB & state boards",
              },
              {
                I: BookOpen,
                t: "5 Roundtables",
                d: "covering pedagogy, AI, NEP 2.0",
              },
              {
                I: Globe2,
                t: "20 Countries",
                d: "international academic observers",
              },
            ].map(({ I, t, d }) => (
              <div
                key={t}
                className="glass border-glow rounded-2xl p-5 text-center"
              >
                <I className="size-6 text-primary mx-auto" />
                <div className="mt-3 font-display text-lg font-semibold">
                  {t}
                </div>
                <div className="text-xs text-muted-foreground">{d}</div>
              </div>
            ))}
          </div>

          {/* Focus Areas */}
          <div className="mt-14">
            <div className="text-center">
              <div className="text-[10px] tracking-[0.3em] uppercase text-primary">
                Major Focus Areas
              </div>
              <h2 className="mt-3 font-display text-3xl sm:text-4xl font-bold text-gradient">
                Eight pillars shaping the conversation
              </h2>
            </div>

            <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {FOCUS_AREAS.map(({ I, t }, i) => (
                <div
                  key={t}
                  className="glass border-glow rounded-2xl p-5"
                >
                  <div className="inline-flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent glow-sm">
                    <I className="size-5 text-primary-foreground" />
                  </div>
                  <div className="mt-4 text-sm font-semibold leading-snug">
                    {t}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Key Discussions + Supporters */}
          <div className="mt-14 grid lg:grid-cols-2 gap-5">
            <div className="glass-strong border-glow rounded-3xl p-6 sm:p-8">
              <div className="flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-primary">
                <Target className="size-4" />
                Key Discussions
              </div>

              <ul className="mt-5 space-y-3">
                {DISCUSSIONS.map((d) => (
                  <li
                    key={d}
                    className="flex gap-3 items-start text-sm text-foreground/90"
                  >
                    <span className="mt-1.5 size-1.5 rounded-full bg-gradient-to-r from-primary to-accent shrink-0" />
                    {d}
                  </li>
                ))}
              </ul>
            </div>

            <div className="glass-strong border-glow rounded-3xl p-6 sm:p-8">
              <div className="flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-accent">
                <Award className="size-4" />
                Supported By
              </div>

              <ul className="mt-5 grid sm:grid-cols-2 gap-2">
                {SUPPORTERS.map((s) => (
                  <li
                    key={s}
                    className="glass rounded-xl px-3 py-2 text-xs text-foreground/85"
                  >
                    {s}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Agenda */}
          <div className="mt-14 glass-strong border-glow rounded-3xl p-6 sm:p-10">
            <h2 className="font-display text-2xl font-bold mb-6">
              Agenda · Day 01
            </h2>

            <ul className="space-y-3">
              {AGENDA.map((a, i) => (
                <li
                  key={a.time}
                  className="flex gap-4 items-start glass rounded-xl p-4"
                >
                  <div className="font-mono text-sm text-primary w-16 shrink-0">
                    {a.time}
                  </div>
                  <div className="text-sm text-foreground/90">{a.title}</div>
                </li>
              ))}
            </ul>
          </div>

          {/* Back to Zenith */}
          <div className="mt-12 text-center">
            <Link
              to="/"
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm"
            >
              ← Back to Zenith
            </Link>
          </div>

          {/* Golden Book of Education */}
          <section id="golden-book" className="mt-24 scroll-mt-32">
            <div
              className="text-center"
            >
              <div className="inline-flex items-center gap-2 glass border-glow rounded-full px-4 py-1.5 text-[10px] tracking-[0.3em] uppercase">
                <BookMarked className="size-3 text-primary" />
                Call for Nominations · Global Initiative
              </div>

              <h2 className="mt-6 font-display text-4xl sm:text-6xl font-extrabold leading-[1.05]">
                Golden Book of{" "}
                <span className="text-gradient-primary">Education</span>
              </h2>

              <p className="mt-4 text-sm tracking-[0.25em] uppercase text-accent font-bold">
                The 101 Great Educators Who Have Inspired the World
              </p>

              <p className="mt-5 text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                A prestigious global collection of research, innovations,
                experiences, inspiring stories and scholarly articles — a
                living legacy of wisdom, a treasure of knowledge, and a
                Wikipedia of educational excellence for generations to come.
                Proudly published by the Education Council of the Global
                Chamber of Commerce & Industry.
              </p>
            </div>

            {/* Why Participate + You May Submit */}
            <div className="mt-12 grid lg:grid-cols-2 gap-5">
              <div className="glass-strong border-glow rounded-3xl p-6 sm:p-8">
                <div className="flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-primary">
                  <Trophy className="size-4" />
                  Why You Should Participate
                </div>

                <ul className="mt-5 space-y-3">
                  {[
                    "Showcase your story, research, innovation or educational experience on a global platform.",
                    "Gain recognition as one of The 101 Great Educators Who Have Inspired the World.",
                    "Be part of a publication whose reach will extend to millions of readers worldwide.",
                    "Receive the honor of being formally recognized by the Hon'ble Education Minister.",
                    "Inspire future generations by contributing to a timeless educational legacy.",
                    "Be the change you wish to see in the world.",
                  ].map((d) => (
                    <li
                      key={d}
                      className="flex gap-3 items-start text-sm text-foreground/90"
                    >
                      <CheckCircle2 className="size-4 text-primary shrink-0 mt-0.5" />
                      {d}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="glass-strong border-glow rounded-3xl p-6 sm:p-8">
                <div className="flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-accent">
                  <FileText className="size-4" />
                  You May Submit
                </div>

                <div className="mt-5 grid sm:grid-cols-2 gap-2">
                  {[
                    "A story",
                    "An article",
                    "Research work",
                    "A case study",
                    "Personal educational experiences",
                    "Innovative practices in teaching & learning",
                  ].map((d) => (
                    <div
                      key={d}
                      className="glass rounded-xl px-3 py-2.5 text-xs text-foreground/90"
                    >
                      {d}
                    </div>
                  ))}
                </div>

                <div className="mt-6 glass border-glow rounded-2xl p-4">
                  <div className="text-[10px] tracking-[0.3em] uppercase text-primary">
                    Who Can Apply
                  </div>
                  <p className="mt-2 text-sm text-foreground/85">
                    Educators, Chancellors, Vice-Chancellors, Principals,
                    Teachers, Academic Leaders and Change-Makers in Education.
                  </p>
                </div>
              </div>
            </div>

            {/* Terms & Conditions */}
            <div className="mt-6 glass-strong border-glow rounded-3xl p-6 sm:p-8">
              <div className="flex items-center gap-2 text-[10px] tracking-[0.3em] uppercase text-primary">
                <Target className="size-4" />
                Terms & Conditions
              </div>

              <ul className="mt-5 grid sm:grid-cols-2 gap-x-6 gap-y-3">
                {[
                  "Applicant must belong to the education sector.",
                  "Only one manuscript per applicant, written in English.",
                  "Submission must be the author's original work — plagiarism is strictly prohibited.",
                  "Submit 5 colored photographs related to the content.",
                  "Intellectual copyright of the author's work will always remain protected.",
                  "Manuscript in Word file, Times New Roman, 12 pt font.",
                  "Word limit: 1,500 – 2,000 words.",
                  "Self-nominations or nomination of a colleague / fellow educator are welcome.",
                  "Selected winners will be published in the Golden Book of Education.",
                  "Selected contributors will be formally honored by the Education Minister.",
                  "Decision of the reviewing committee shall be final and irrevocable.",
                ].map((d) => (
                  <li
                    key={d}
                    className="flex gap-2 items-start text-xs text-foreground/85 leading-relaxed"
                  >
                    <span className="mt-1.5 size-1.5 rounded-full bg-gradient-to-r from-primary to-accent shrink-0" />
                    {d}
                  </li>
                ))}
              </ul>
            </div>

            {/* Centered Two Cards */}
            <div className="mt-6 flex flex-wrap justify-center gap-4">
              <div className="glass border-glow rounded-2xl p-5 text-center w-full sm:w-[calc(50%-0.5rem)] lg:max-w-sm">
                <Calendar className="size-6 text-primary mx-auto" />
                <div className="mt-3 font-display text-lg font-semibold">
                  20 November 2026
                </div>
                <div className="text-xs text-muted-foreground">
                  Last date of submission
                </div>
              </div>

              <div className="glass border-glow rounded-2xl p-5 text-center w-full sm:w-[calc(50%-0.5rem)] lg:max-w-sm">
                <Users className="size-6 text-primary mx-auto" />
                <div className="mt-3 font-display text-lg font-semibold">
                  101 Educators
                </div>
                <div className="text-xs text-muted-foreground">
                  Honored on a global stage
                </div>
              </div>
            </div>

            {/* Nomination CTA */}
            <div className="mt-8 glass-strong border-glow rounded-3xl p-6 sm:p-10 text-center">
              <p className="text-base sm:text-lg text-foreground/90 max-w-3xl mx-auto leading-relaxed">
                This is not just a nomination. It is an invitation to become
                part of a global educational movement. If your journey has
                inspired learners, transformed institutions, created
                innovation, or touched lives through education — your
                contribution deserves a place in this historic volume.
              </p>

              <p className="mt-4 text-sm tracking-[0.25em] uppercase text-primary font-bold">
                Step forward · Share your vision · Make your mark
              </p>

              <a
                href="mailto:info@gcci.live?subject=Golden%20Book%20of%20Education%20-%20Nomination"
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground glow-sm"
              >
                <Mail className="size-4" />
                Send your nomination → info@gcci.live
              </a>
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
}
