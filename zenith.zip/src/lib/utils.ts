import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Prefix an app-absolute link (starting with "/") with the Vite base path so
 * raw <a href> anchors resolve under the deployed subpath (e.g. "/zenith/").
 * Leaves relative, hash-only, mailto, and external links untouched.
 * Works for both subpath ("/zenith/") and root ("/") deployments.
 */
export function withBase(path: string): string {
  if (!path.startsWith("/")) return path;
  const base = import.meta.env.BASE_URL.replace(/\/$/, ""); // "/zenith/" -> "/zenith", "/" -> ""
  return `${base}${path}`;
}
