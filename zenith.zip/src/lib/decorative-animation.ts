/** Keep decorative work off the mobile main thread and stop it outside the viewport. */
export function animateWhenVisible(
  element: HTMLElement,
  draw: (elapsedSeconds: number) => void,
  fps = 30,
) {
  const media = window.matchMedia(
    "(min-width: 768px) and (pointer: fine) and (hover: hover) and (prefers-reduced-motion: no-preference)",
  );
  let inView = false;
  let frame = 0;
  let previous = 0;
  const tick = (now: number) => {
    if (now - previous >= 1000 / fps) {
      draw(Math.min((now - previous) / 1000, 0.1));
      previous = now;
    }
    frame = requestAnimationFrame(tick);
  };
  const update = () => {
    const active = media.matches && inView && !document.hidden;
    element.dataset.animate = String(active);
    if (active && !frame) {
      previous = performance.now();
      frame = requestAnimationFrame(tick);
    } else if (!active && frame) {
      cancelAnimationFrame(frame);
      frame = 0;
    }
  };
  // IntersectionObserver controls decoration only; it never gates page content.
  const observer =
    typeof IntersectionObserver === "undefined"
      ? null
      : new IntersectionObserver(([entry]) => {
          inView = entry.isIntersecting;
          update();
        });
  if (observer) observer.observe(element);
  else inView = true;
  media.addEventListener("change", update);
  document.addEventListener("visibilitychange", update);
  update();
  return () => {
    cancelAnimationFrame(frame);
    observer?.disconnect();
    media.removeEventListener("change", update);
    document.removeEventListener("visibilitychange", update);
    element.dataset.animate = "false";
  };
}
